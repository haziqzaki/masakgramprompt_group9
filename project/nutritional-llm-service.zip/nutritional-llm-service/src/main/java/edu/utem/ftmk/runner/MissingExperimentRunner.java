package edu.utem.ftmk.runner;

import com.google.gson.*;
import com.google.gson.stream.JsonReader;
import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.ollama.OllamaChatModel;

import java.sql.*;
import java.time.Duration;
import java.util.*;
import java.io.StringReader;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MissingExperimentRunner {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/masakgramprompt?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kuala_Lumpur";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private static final String OLLAMA_BASE_URL = "http://localhost:11434";

    // ★ ALL MODELS - ALL UNCOMMENTED
    private static final String[] MODELS = {
        "llama3.2:3b",
        "phi4-mini",
        "qwen2.5:3b",
        "aisingapore/Gemma-SEA-LION-v4-4B-VL",
        "medgemma:4b"
    };

    // ★ ALL TECHNIQUES - ALL UNCOMMENTED
    private static final String[] TECHNIQUES = {
        "zero-shot",
        "few-shot",
        "chain-of-thought",
        "structured-output"
    };

    private static final Set<String> WORKING_COMBINATIONS = new HashSet<>();
    private static final Set<String> FAILED_COMBINATIONS = new HashSet<>();
    private static final Set<String> PROCESSED_IN_RUN = new HashSet<>();

    private static final Set<String> HEAVY_MODELS = new HashSet<>(Arrays.asList(
        "qwen2.5:3b",
        "aisingapore/Gemma-SEA-LION-v4-4B-VL",
        "medgemma:4b"
    ));

    // ★ CRASH_COMBINATIONS IS EMPTY - WILL RUN EVERYTHING
    private static final Set<String> CRASH_COMBINATIONS = new HashSet<>();

    public static void main(String[] args) {
        MissingExperimentRunner runner = new MissingExperimentRunner();
        runner.runMissingExperiments();
    }

    public void runMissingExperiments() {
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║         🔍 Running ALL Missing Experiments              ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");

        if (!checkOllamaStatus()) {
            System.out.println("❌ Ollama is not running! Please start Ollama first.");
            return;
        }

        List<Integer> transcriptIds = getTranscriptIds();
        if (transcriptIds.isEmpty()) {
            System.out.println("❌ No transcripts found!");
            return;
        }

        List<MissingExperiment> missing = findMissingExperiments(transcriptIds);

        if (missing.isEmpty()) {
            System.out.println("\n✅ ALL experiments are complete!");
            printSummary();
            return;
        }

        System.out.println("\n📊 Found " + missing.size() + " missing experiments to run.");
        System.out.println("⚠️  WARNING: This includes heavy/crash-prone combinations!");
        System.out.println("=====================================\n");

        int success = 0;
        int failed = 0;

        for (MissingExperiment exp : missing) {
            String runKey = exp.transcriptId + "|" + exp.modelTag + "|" + exp.techniqueName;
            if (PROCESSED_IN_RUN.contains(runKey)) {
                System.out.println("⏭️ Skipping duplicate: Video " + exp.transcriptId + " | " + exp.modelTag + " | " + exp.techniqueName);
                continue;
            }
            PROCESSED_IN_RUN.add(runKey);

            // ★ CRASH CHECK IS NOW DISABLED - WILL RUN EVERYTHING
            String crashKey = exp.modelTag + "|" + exp.techniqueName;
            if (CRASH_COMBINATIONS.contains(crashKey)) {
                System.out.println("⏭️ Skipping known crash combination: " + crashKey);
                failed++;
                continue;
            }

            try {
                System.out.print("[" + (success + failed + 1) + "/" + missing.size() + 
                               "] Video: " + exp.transcriptId + 
                               " | Model: " + exp.modelTag + 
                               " | Technique: " + exp.techniqueName + " ... ");

                if (!isModelInstalled(exp.modelTag)) {
                    System.out.println("⚠️ Model not installed, skipping...");
                    failed++;
                    continue;
                }

                String transcript = getTranscriptContent(exp.transcriptId);
                String systemPrompt = getSystemPrompt(exp.techniqueName);
                String userPrompt = getUserPrompt(exp.techniqueName, transcript);
                
                // ★ Increased timeouts for heavy models
                Duration timeout = HEAVY_MODELS.contains(exp.modelTag) ? 
                    Duration.ofMinutes(25) : Duration.ofMinutes(15);
                
                String response = sendPrompt(exp.modelTag, systemPrompt, userPrompt, timeout);

                System.out.println("\n   📊 Response length: " + response.length() + " characters");
                System.out.println("   📝 Raw Response (first 300 chars):");
                System.out.println("   " + response.substring(0, Math.min(response.length(), 300)) + "...");

                if (!isValidJson(response)) {
                    System.out.println("   ⚠️ Invalid JSON response, marking as failed");
                    upsertFailedExperiment(exp.transcriptId, exp.modelId, exp.techniqueId);
                    String key = exp.modelTag + "|" + exp.techniqueName;
                    FAILED_COMBINATIONS.add(key);
                    failed++;
                    continue;
                }

                saveResult(exp.transcriptId, exp.modelId, exp.techniqueId, response);

                String key = exp.modelTag + "|" + exp.techniqueName;
                WORKING_COMBINATIONS.add(key);
                System.out.println("✅ SUCCESS");
                success++;

            } catch (Exception e) {
                System.out.println("❌ FAILED: " + e.getMessage());
                
                // ★ Add to crash list if it crashed
                if (e.getMessage() != null && 
                    (e.getMessage().contains("OutOfMemory") || 
                     e.getMessage().contains("timeout") ||
                     e.getMessage().contains("connection") ||
                     e.getMessage().contains("unable to get") ||
                     e.getMessage().contains("could not"))) {
                    System.out.println("   ⚠️ Adding to crash list: " + exp.modelTag + "|" + exp.techniqueName);
                    CRASH_COMBINATIONS.add(exp.modelTag + "|" + exp.techniqueName);
                }
                
                String key = exp.modelTag + "|" + exp.techniqueName;
                FAILED_COMBINATIONS.add(key);
                upsertFailedExperiment(exp.transcriptId, exp.modelId, exp.techniqueId);
                failed++;
            }

            // ★ Longer sleep for heavy models
            try { 
                long sleepTime = HEAVY_MODELS.contains(exp.modelTag) ? 8000 : 3000;
                Thread.sleep(sleepTime); 
            } catch (InterruptedException e) {}
        }

        System.out.println("\n=====================================");
        System.out.println("✅ MISSING EXPERIMENTS COMPLETE!");
        System.out.println("   Total  : " + missing.size());
        System.out.println("   Success: " + success);
        System.out.println("   Failed : " + failed);
        printSummary();
        System.out.println("=====================================");
    }

    // ──────────────────────────────────────────────────────────────
    // ★ CHECK OLLAMA STATUS
    // ──────────────────────────────────────────────────────────────

    private boolean checkOllamaStatus() {
        try {
            ProcessBuilder pb = new ProcessBuilder("ollama", "list");
            Process p = pb.start();
            int exitCode = p.waitFor();
            return exitCode == 0;
        } catch (Exception e) {
            return false;
        }
    }

    // ──────────────────────────────────────────────────────────────
    // ★ CHECK IF MODEL IS INSTALLED
    // ──────────────────────────────────────────────────────────────

    private boolean isModelInstalled(String modelTag) {
        try {
            ProcessBuilder pb = new ProcessBuilder("ollama", "list");
            Process p = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(modelTag)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    // ──────────────────────────────────────────────────────────────
    // ★ UPSERT for failed experiments
    // ──────────────────────────────────────────────────────────────

    private void upsertFailedExperiment(int transcriptId, int modelId, int techniqueId) {
    	   String checkSql = "SELECT experiment_id, status FROM experiment WHERE transcript_id = ? AND model_id = ? AND technique_id = ? AND rag_enabled = FALSE";        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            
            checkStmt.setInt(1, transcriptId);
            checkStmt.setInt(2, modelId);
            checkStmt.setInt(3, techniqueId);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                int existingId = rs.getInt("experiment_id");
                String currentStatus = rs.getString("status");
                
                if ("failed".equals(currentStatus) || "pending".equals(currentStatus)) {
                    String updateSql = "UPDATE experiment SET status = 'failed', executed_at = NOW() WHERE experiment_id = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                        updateStmt.setInt(1, existingId);
                        updateStmt.executeUpdate();
                        System.out.println("   🔄 Updated existing experiment (ID: " + existingId + ") to 'failed'");
                    }
                } else if ("completed".equals(currentStatus)) {
                    System.out.println("   ℹ️ Experiment already completed (ID: " + existingId + "), skipping");
                }
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        String sql = "INSERT INTO experiment (transcript_id, model_id, technique_id, rag_enabled, status, executed_at) " +
                     "VALUES (?, ?, ?, FALSE, 'failed', NOW())";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transcriptId);
            pstmt.setInt(2, modelId);
            pstmt.setInt(3, techniqueId);
            pstmt.executeUpdate();
            System.out.println("   📝 Inserted new failed experiment record");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // ──────────────────────────────────────────────────────────────
    // ★ PRINT SUMMARY
    // ──────────────────────────────────────────────────────────────

    private void printSummary() {
        System.out.println("\n📊 Working Combinations:");
        if (WORKING_COMBINATIONS.isEmpty()) {
            System.out.println("   None yet. Keep running!");
        } else {
            for (String combo : WORKING_COMBINATIONS) {
                System.out.println("   ✅ " + combo);
            }
        }
        
        System.out.println("\n❌ Failed Combinations:");
        if (FAILED_COMBINATIONS.isEmpty()) {
            System.out.println("   None yet.");
        } else {
            for (String combo : FAILED_COMBINATIONS) {
                System.out.println("   ❌ " + combo);
            }
        }

        System.out.println("\n⏭️ Skipped Combinations (known crashes):");
        if (CRASH_COMBINATIONS.isEmpty()) {
            System.out.println("   None yet.");
        } else {
            for (String combo : CRASH_COMBINATIONS) {
                System.out.println("   ⏭️ " + combo);
            }
        }
    }

    // ──────────────────────────────────────────────────────────────
    // FIND MISSING EXPERIMENTS
    // ──────────────────────────────────────────────────────────────

    private List<MissingExperiment> findMissingExperiments(List<Integer> transcriptIds) {
        List<MissingExperiment> missing = new ArrayList<>();
        Set<String> existing = getExistingCombinations();

        for (int transcriptId : transcriptIds) {
            for (String modelTag : MODELS) {
                int modelId = getModelId(modelTag);
                if (modelId == -1) continue;

                for (String techniqueName : TECHNIQUES) {
                    int techniqueId = getTechniqueId(techniqueName);
                    if (techniqueId == -1) continue;

                    String key = transcriptId + "|" + modelId + "|" + techniqueId;
                    if (!existing.contains(key)) {
                        MissingExperiment exp = new MissingExperiment();
                        exp.transcriptId = transcriptId;
                        exp.modelId = modelId;
                        exp.modelTag = modelTag;
                        exp.techniqueId = techniqueId;
                        exp.techniqueName = techniqueName;
                        missing.add(exp);
                    }
                }
            }
        }
        return missing;
    }

    private Set<String> getExistingCombinations() {
        Set<String> existing = new HashSet<>();
        // ★ ONLY check RAG = FALSE (Phase 1)
        String sql = "SELECT transcript_id, model_id, technique_id, rag_enabled FROM experiment WHERE status IN ('completed', 'failed') AND rag_enabled = FALSE";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                existing.add(rs.getInt("transcript_id") + "|" + rs.getInt("model_id") + "|" + rs.getInt("technique_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return existing;
    }

    // ──────────────────────────────────────────────────────────────
    // DATABASE METHODS
    // ──────────────────────────────────────────────────────────────

    private List<Integer> getTranscriptIds() {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT transcript_id FROM transcript ORDER BY transcript_id";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                ids.add(rs.getInt("transcript_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ids;
    }

    private String getTranscriptContent(int transcriptId) {
        // First, get the file path from the database
        String sql = "SELECT file_path FROM transcript WHERE transcript_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transcriptId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String filePath = rs.getString("file_path");
                if (filePath != null && !filePath.isEmpty()) {
                    try {
                        // Fix Windows path if needed
                        String fixedPath = filePath.replace("\\", "/");
                        java.nio.file.Path path = java.nio.file.Paths.get(fixedPath);
                        if (java.nio.file.Files.exists(path)) {
                            String content = new String(java.nio.file.Files.readAllBytes(path), 
                                                        java.nio.charset.StandardCharsets.UTF_8);
                            System.out.println("   📄 Read transcript from: " + fixedPath);
                            return content;
                        } else {
                            System.out.println("   ⚠️ File not found: " + fixedPath);
                        }
                    } catch (Exception e) {
                        System.out.println("   ⚠️ Failed to read file: " + filePath + " - " + e.getMessage());
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Transcript not found for ID: " + transcriptId;
    }

    private int getModelId(String modelTag) {
        String sql = "SELECT model_id FROM llm_model WHERE model_tag = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, modelTag);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("model_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getTechniqueId(String techniqueName) {
        String sql = "SELECT technique_id FROM prompt_technique WHERE technique_name = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, techniqueName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("technique_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    // ★ FIXED: Check if experiment exists before inserting
    private int insertExperiment(int transcriptId, int modelId, int techniqueId) {
        // ★ First check if experiment already exists
        String checkSql = "SELECT experiment_id FROM experiment WHERE transcript_id = ? AND model_id = ? AND technique_id = ? AND rag_enabled = FALSE";        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            
            checkStmt.setInt(1, transcriptId);
            checkStmt.setInt(2, modelId);
            checkStmt.setInt(3, techniqueId);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                int existingId = rs.getInt("experiment_id");
                System.out.println("   ℹ️ Experiment already exists (ID: " + existingId + "), updating to completed");
                
                String updateSql = "UPDATE experiment SET status = 'completed', executed_at = NOW() WHERE experiment_id = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setInt(1, existingId);
                    updateStmt.executeUpdate();
                }
                return existingId;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        // ★ If no existing record, insert new one
        String sql = "INSERT INTO experiment (transcript_id, model_id, technique_id, rag_enabled, status, executed_at) " +
                     "VALUES (?, ?, ?, FALSE, 'completed', NOW())";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, transcriptId);
            pstmt.setInt(2, modelId);
            pstmt.setInt(3, techniqueId);
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int insertNutritionResult(int experimentId, String jsonResponse) {
        String sql = "INSERT INTO nutrition_result (experiment_id, raw_json_output, json_valid, created_at) " +
                     "VALUES (?, ?, TRUE, NOW())";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, experimentId);
            pstmt.setString(2, jsonResponse);
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private void saveResult(int transcriptId, int modelId, int techniqueId, String response) {
        int experimentId = insertExperiment(transcriptId, modelId, techniqueId);
        if (experimentId > 0) {
            int nutritionResultId = insertNutritionResult(experimentId, response);
            if (nutritionResultId > 0) {
                parseAndInsertIngredients(nutritionResultId, response);
            }
        }
    }

    // ──────────────────────────────────────────────────────────────
    // ★ VALIDATE JSON BEFORE SAVING
    // ──────────────────────────────────────────────────────────────

    private boolean isValidJson(String response) {
        try {
            String cleaned = cleanJsonResponse(response);
            if (cleaned == null) return false;
            
            try {
                JsonReader reader = new JsonReader(new StringReader(cleaned));
                reader.setLenient(true);
                JsonElement element = JsonParser.parseReader(reader);
                return element.isJsonObject() || element.isJsonArray();
            } catch (JsonSyntaxException e) {
                String fixed = cleaned;
                fixed = fixed.replaceAll(":\\s*null\\s*", ": 0");
                fixed = fixed.replaceAll("\"\\s*:\\s*null\\s*", "\": \"\"");
                fixed = fixed.replaceAll(",\\s*}", "}");
                fixed = fixed.replaceAll(",\\s*]", "]");
                
                try {
                    JsonReader reader = new JsonReader(new StringReader(fixed));
                    reader.setLenient(true);
                    JsonElement element = JsonParser.parseReader(reader);
                    return element.isJsonObject() || element.isJsonArray();
                } catch (JsonSyntaxException e2) {
                    return false;
                }
            }
        } catch (Exception e) {
            return false;
        }
    }

    // ──────────────────────────────────────────────────────────────
    // ★ PARSE AND INSERT INGREDIENTS
    // ──────────────────────────────────────────────────────────────

    private void parseAndInsertIngredients(int nutritionResultId, String jsonResponse) {
        try {
            System.out.println("\n   🔍 Parsing JSON...");
            
            String cleanedJson = cleanJsonResponse(jsonResponse);
            if (cleanedJson == null) {
                System.out.println("   ⚠️ No JSON found in response");
                return;
            }

            JsonArray ingredients = null;
            
            try {
                JsonReader reader = new JsonReader(new StringReader(cleanedJson));
                reader.setLenient(true);
                JsonElement rootElement = JsonParser.parseReader(reader);
                
                if (rootElement.isJsonObject()) {
                    JsonObject root = rootElement.getAsJsonObject();
                    ingredients = findIngredients(root);
                } else if (rootElement.isJsonArray()) {
                    ingredients = rootElement.getAsJsonArray();
                }
                
            } catch (JsonSyntaxException e) {
                System.out.println("   ⚠️ JSON parsing failed: " + e.getMessage());
                
                String fixedJson = cleanedJson;
                if (!cleanedJson.endsWith("}") && !cleanedJson.endsWith("]")) {
                    if (cleanedJson.contains("{") && !cleanedJson.endsWith("}")) {
                        fixedJson = cleanedJson + "}";
                    } else if (cleanedJson.contains("[") && !cleanedJson.endsWith("]")) {
                        fixedJson = cleanedJson + "]";
                    }
                }
                
                fixedJson = fixedJson.replaceAll(":\\s*null\\s*", ": 0");
                fixedJson = fixedJson.replaceAll("\"\\s*:\\s*null\\s*", "\": \"\"");
                fixedJson = fixedJson.replaceAll(",\\s*}", "}");
                fixedJson = fixedJson.replaceAll(",\\s*]", "]");
                
                try {
                    System.out.println("   🔧 Attempting to repair JSON...");
                    JsonReader reader = new JsonReader(new StringReader(fixedJson));
                    reader.setLenient(true);
                    JsonElement rootElement = JsonParser.parseReader(reader);
                    
                    if (rootElement.isJsonObject()) {
                        JsonObject root = rootElement.getAsJsonObject();
                        ingredients = findIngredients(root);
                        System.out.println("   ✅ JSON repaired successfully");
                    } else if (rootElement.isJsonArray()) {
                        ingredients = rootElement.getAsJsonArray();
                        System.out.println("   ✅ JSON repaired successfully");
                    }
                } catch (JsonSyntaxException e2) {
                    System.out.println("   ⚠️ Even with repair, JSON parsing failed");
                    System.out.println("   📝 Raw response (first 500 chars):");
                    System.out.println("   " + jsonResponse.substring(0, Math.min(jsonResponse.length(), 500)));
                    return;
                }
            }

            if (ingredients == null || ingredients.size() == 0) {
                System.out.println("   ⚠️ No ingredients found in JSON");
                return;
            }

            JsonObject firstIng = ingredients.get(0).getAsJsonObject();
            String firstName = getStringLenient(firstIng, "ingredient_name_original", "name_original", "ingredient", "name", "item");
            
            if (firstName != null && (firstName.contains(",") || firstName.contains(" and ") || firstName.contains(" & "))) {
                System.out.println("   🔍 Splitting comma-separated ingredients...");
                ingredients = splitCommaSeparatedIngredients(firstName, firstIng);
            }

            String sql = "INSERT INTO ingredient_result (" +
                "result_id, name_original, name_en, quantity_value, " +
                "unit_original, unit_en, estimated_weight_g, " +
                "calories, total_fat_g, saturated_fat_g, cholesterol_mg, " +
                "sodium_mg, total_carbohydrate_g, dietary_fiber_g, " +
                "total_sugars_g, protein_g, vitamin_d_mcg, calcium_mg, iron_mg, potassium_mg" +
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            int inserted = 0;
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {

                for (JsonElement element : ingredients) {
                    JsonObject ing = element.getAsJsonObject();

                    String nameOriginal = getStringLenient(ing, "ingredient_name_original", "name_original", "ingredient", "name", "item", "original_name");
                    String nameEn = getStringLenient(ing, "ingredient_name_en", "name_en", "english_name", "en_name");
                    
                    if (nameOriginal == null || nameOriginal.isEmpty()) {
                        continue;
                    }

                    if (nameOriginal.contains(",") || nameOriginal.contains(" and ") || nameOriginal.contains(" & ")) {
                        continue;
                    }

                    double quantity = getDoubleLenient(ing, "quantity_value", "quantity", "qty", "amount", "value");
                    String unitOriginal = getStringLenient(ing, "quantity_unit_original", "unit_original", "unit");
                    String unitEn = getStringLenient(ing, "quantity_unit_en", "unit_en", "english_unit");
                    double weight = getDoubleLenient(ing, "estimated_weight_g", "weight_g", "weight", "grams");
                    double calories = getDoubleLenient(ing, "calories", "cal", "energy", "kcal");
                    double protein = getDoubleLenient(ing, "protein_g", "protein", "protein_grams");
                    double carbs = getDoubleLenient(ing, "total_carbohydrate_g", "carbohydrate_g", "carbs", "carbohydrates");
                    double fat = getDoubleLenient(ing, "total_fat_g", "fat_g", "fat", "total_fat");

                    pstmt.setInt(1, nutritionResultId);
                    pstmt.setString(2, nameOriginal);
                    pstmt.setString(3, nameEn);
                    pstmt.setDouble(4, quantity);
                    pstmt.setString(5, unitOriginal);
                    pstmt.setString(6, unitEn);
                    pstmt.setDouble(7, weight);
                    pstmt.setDouble(8, calories);
                    pstmt.setDouble(9, fat);
                    pstmt.setDouble(10, 0.0);
                    pstmt.setDouble(11, 0.0);
                    pstmt.setDouble(12, 0.0);
                    pstmt.setDouble(13, carbs);
                    pstmt.setDouble(14, 0.0);
                    pstmt.setDouble(15, 0.0);
                    pstmt.setDouble(16, protein);
                    pstmt.setDouble(17, 0.0);
                    pstmt.setDouble(18, 0.0);
                    pstmt.setDouble(19, 0.0);
                    pstmt.setDouble(20, 0.0);
                    
                    pstmt.addBatch();
                    inserted++;
                }
                
                pstmt.executeBatch();
                System.out.println("   ✅ Parsed " + inserted + " ingredients");
            }

        } catch (Exception e) {
            System.err.println("   ⚠️ Failed to parse ingredients: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ──────────────────────────────────────────────────────────────
    // ★ HELPER: Find ingredients array
    // ──────────────────────────────────────────────────────────────

    private JsonArray findIngredients(JsonObject root) {
        String[] possibleArrayNames = {"ingredients", "ingredient", "items", "data", "results", "recipe_ingredients"};
        
        for (String name : possibleArrayNames) {
            if (root.has(name)) {
                try {
                    return root.getAsJsonArray(name);
                } catch (Exception e) {
                    try {
                        JsonObject ingObj = root.getAsJsonObject(name);
                        if (ingObj != null) {
                            JsonArray arr = new JsonArray();
                            arr.add(ingObj);
                            return arr;
                        }
                    } catch (Exception e2) {
                        try {
                            String str = root.get(name).getAsString();
                            if (str != null && !str.isEmpty()) {
                                JsonReader strReader = new JsonReader(new StringReader(str));
                                strReader.setLenient(true);
                                JsonElement el = JsonParser.parseReader(strReader);
                                if (el.isJsonArray()) {
                                    return el.getAsJsonArray();
                                }
                            }
                        } catch (Exception e3) {
                            // Ignore
                        }
                    }
                }
            }
        }
        return null;
    }

    // ──────────────────────────────────────────────────────────────
    // ★ HELPER: Split comma-separated ingredients
    // ──────────────────────────────────────────────────────────────

    private JsonArray splitCommaSeparatedIngredients(String commaList, JsonObject template) {
        JsonArray result = new JsonArray();
        String[] parts = commaList.split("[,、，]|\\s+and\\s+|\\s+&\\s+");
        
        for (String part : parts) {
            part = part.trim();
            if (part.isEmpty()) continue;
            
            JsonObject newIng = new JsonObject();
            
            for (Map.Entry<String, JsonElement> entry : template.entrySet()) {
                String key = entry.getKey();
                JsonElement value = entry.getValue();
                
                if (key.equals("ingredient_name_original") || key.equals("name_original") || 
                    key.equals("ingredient") || key.equals("name") || key.equals("item")) {
                    continue;
                }
                
                newIng.add(key, value);
            }
            
            newIng.addProperty("ingredient_name_original", part);
            newIng.addProperty("name_original", part);
            newIng.addProperty("ingredient", part);
            newIng.addProperty("quantity_value", 1.0);
            
            result.add(newIng);
        }
        
        return result;
    }

    // ──────────────────────────────────────────────────────────────
    // ★ HELPER: Clean JSON Response
    // ──────────────────────────────────────────────────────────────

    private String cleanJsonResponse(String raw) {
        if (raw == null || raw.isEmpty()) return null;
        
        String cleaned = raw.replaceAll("(?s)```json\\s*", "");
        cleaned = cleaned.replaceAll("(?s)```\\s*", "");
        
        if (cleaned.startsWith("{") && !cleaned.endsWith("}") && cleaned.contains("}{")) {
            cleaned = "[" + cleaned.replaceAll("}\\s*\\{", "},{") + "]";
            System.out.println("   🔧 Converted multiple JSON objects to array");
        }
        
        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        
        if (start >= 0 && end > start) {
            String json = cleaned.substring(start, end + 1).trim();
            if (!isJsonComplete(json)) {
                System.out.println("   🔧 JSON appears truncated, attempting to repair...");
                
                int openBraces = countChar(json, '{');
                int closeBraces = countChar(json, '}');
                int openBrackets = countChar(json, '[');
                int closeBrackets = countChar(json, ']');
                
                for (int i = 0; i < openBraces - closeBraces; i++) {
                    json = json + "}";
                }
                for (int i = 0; i < openBrackets - closeBrackets; i++) {
                    json = json + "]";
                }
                
                json = json.replaceAll(",\\s*}", "}");
                json = json.replaceAll(",\\s*]", "]");
                json = json.replaceAll(":\\s*null\\s*", ": 0");
                json = json.replaceAll("\"\\s*:\\s*null\\s*", "\": \"\"");
                
                System.out.println("   🔧 Repaired JSON (added " + (openBraces - closeBraces) + " braces)");
            }
            return json;
        }
        
        start = cleaned.indexOf('[');
        end = cleaned.lastIndexOf(']');
        if (start >= 0 && end > start) {
            String json = cleaned.substring(start, end + 1).trim();
            if (!isJsonComplete(json)) {
                int openBrackets = countChar(json, '[');
                int closeBrackets = countChar(json, ']');
                for (int i = 0; i < openBrackets - closeBrackets; i++) {
                    json = json + "]";
                }
            }
            return json;
        }
        
        return null;
    }

    // ──────────────────────────────────────────────────────────────
    // ★ HELPER: Check if JSON is complete
    // ──────────────────────────────────────────────────────────────

    private boolean isJsonComplete(String json) {
        int braces = 0;
        int brackets = 0;
        boolean inString = false;
        char escape = 0;
        
        for (char c : json.toCharArray()) {
            if (escape != 0) {
                escape = 0;
                continue;
            }
            if (c == '\\') {
                escape = c;
                continue;
            }
            if (c == '"' && inString) {
                inString = false;
            } else if (c == '"' && !inString) {
                inString = true;
            }
            if (inString) continue;
            if (c == '{') braces++;
            if (c == '}') braces--;
            if (c == '[') brackets++;
            if (c == ']') brackets--;
        }
        
        return braces == 0 && brackets == 0;
    }

    // ──────────────────────────────────────────────────────────────
    // ★ HELPER: Count characters
    // ──────────────────────────────────────────────────────────────

    private int countChar(String str, char c) {
        int count = 0;
        for (char ch : str.toCharArray()) {
            if (ch == c) count++;
        }
        return count;
    }

    // ──────────────────────────────────────────────────────────────
    // ★ HELPER: Get String from multiple possible field names
    // ──────────────────────────────────────────────────────────────

    private String getStringLenient(JsonObject obj, String... keys) {
        for (String key : keys) {
            if (obj.has(key) && !obj.get(key).isJsonNull()) {
                try {
                    return obj.get(key).getAsString().trim();
                } catch (Exception e) {
                    try {
                        return obj.get(key).toString().replaceAll("^\"|\"$", "");
                    } catch (Exception e2) {
                        // Ignore
                    }
                }
            }
        }
        return null;
    }

    // ──────────────────────────────────────────────────────────────
    // ★ HELPER: Get Double from multiple possible field names
    // ──────────────────────────────────────────────────────────────

    private double getDoubleLenient(JsonObject obj, String... keys) {
        for (String key : keys) {
            if (obj.has(key) && !obj.get(key).isJsonNull()) {
                try {
                    return obj.get(key).getAsDouble();
                } catch (Exception e) {
                    try {
                        String val = obj.get(key).getAsString();
                        val = val.replaceAll("[^0-9.]", "");
                        if (!val.isEmpty()) {
                            return Double.parseDouble(val);
                        }
                    } catch (Exception e2) {
                        // Ignore
                    }
                }
            }
        }
        return 0.0;
    }

    // ──────────────────────────────────────────────────────────────
    // PROMPT METHODS
    // ──────────────────────────────────────────────────────────────

    private String getSystemPrompt(String technique) {
        String baseInstruction =
            "⚠️ CRITICAL: Return ONLY valid JSON with EXACT field names.\n" +
            "⚠️ DO NOT include any explanation, markdown, or text outside the JSON.\n" +
            "⚠️ Start with { and end with }.\n\n" +
            "⚠️ IMPORTANT: List EACH ingredient as a SEPARATE object in the ingredients array.\n" +
            "⚠️ DO NOT combine multiple ingredients into one string with commas.\n\n" +
            "Example of CORRECT format:\n" +
            "\"ingredients\": [\n" +
            "  {\"ingredient_name_original\": \"bawang besar\", \"quantity_value\": 1},\n" +
            "  {\"ingredient_name_original\": \"tomato\", \"quantity_value\": 1},\n" +
            "  {\"ingredient_name_original\": \"cili\", \"quantity_value\": 5}\n" +
            "]\n\n" +
            "The JSON MUST have these fields:\n" +
            "{\n" +
            "  \"recipe_name\": \"\",\n" +
            "  \"servings_estimated\": 0,\n" +
            "  \"ingredients\": [\n" +
            "    {\n" +
            "      \"ingredient_name_original\": \"bawang besar\",\n" +
            "      \"ingredient_name_en\": \"onion\",\n" +
            "      \"quantity_value\": 1,\n" +
            "      \"quantity_unit_original\": \"biji\",\n" +
            "      \"quantity_unit_en\": \"piece\",\n" +
            "      \"estimated_weight_g\": 120,\n" +
            "      \"calories\": 48,\n" +
            "      \"protein_g\": 1.2,\n" +
            "      \"total_carbohydrate_g\": 11.2,\n" +
            "      \"total_fat_g\": 0.1\n" +
            "    }\n" +
            "  ],\n" +
            "  \"nutrition_total\": {\n" +
            "    \"calories\": 0,\n" +
            "    \"protein_g\": 0,\n" +
            "    \"total_carbohydrate_g\": 0,\n" +
            "    \"total_fat_g\": 0\n" +
            "  }\n" +
            "}\n\n" +
            "Extract ingredients and nutrition from the transcript.\n" +
            "Return valid JSON only.";

        switch (technique) {
            case "zero-shot": return baseInstruction;
            case "few-shot": 
                return baseInstruction + 
                    "\n\nExample: {\"recipe_name\":\"Telur Goreng\",\"servings_estimated\":1,\"ingredients\":[{\"ingredient_name_original\":\"telur\",\"ingredient_name_en\":\"egg\",\"quantity_value\":2,\"quantity_unit_original\":\"biji\",\"quantity_unit_en\":\"piece\",\"estimated_weight_g\":100,\"calories\":155,\"protein_g\":13,\"total_carbohydrate_g\":1,\"total_fat_g\":11}],\"nutrition_total\":{\"calories\":155,\"protein_g\":13,\"total_carbohydrate_g\":1,\"total_fat_g\":11}}";
            case "chain-of-thought": 
                return "Think step by step, then return ONLY valid JSON.\n" + baseInstruction;
            case "structured-output": 
                return "Return ONLY valid JSON matching the schema.\n" + baseInstruction;
            default: return baseInstruction;
        }
    }

    private String getUserPrompt(String technique, String transcript) {
        String base = "Analyze this transcript and return ONLY valid JSON:\n\n" + transcript;
        
        switch (technique) {
            case "zero-shot": return base;
            case "few-shot": return "Example: {\"recipe_name\":\"Telur Goreng\",\"ingredients\":[{\"ingredient_name_original\":\"telur\",\"quantity_value\":2,\"unit_original\":\"biji\"}]}\n\n" + base;
            case "chain-of-thought": return "Think step by step, then return ONLY valid JSON.\n\n" + base;
            case "structured-output": return "Return ONLY valid JSON matching the schema.\n\n" + base;
            default: return base;
        }
    }

    private String sendPrompt(String modelTag, String systemPrompt, String userPrompt, Duration timeout) {
        ChatModel chatModel = OllamaChatModel.builder()
                .baseUrl(OLLAMA_BASE_URL)
                .modelName(modelTag)
                .timeout(timeout)
                .build();

        String fullPrompt = systemPrompt + "\n\n" + userPrompt;
        return chatModel.chat(fullPrompt);
    }

    private static class MissingExperiment {
        int transcriptId;
        int modelId;
        String modelTag;
        int techniqueId;
        String techniqueName;
    }
}