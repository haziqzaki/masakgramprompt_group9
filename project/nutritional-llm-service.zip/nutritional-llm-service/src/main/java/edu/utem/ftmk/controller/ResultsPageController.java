package edu.utem.ftmk.controller;

import edu.utem.ftmk.dto.ExperimentResultDTO;
import edu.utem.ftmk.service.ResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Map;

@Controller
public class ResultsPageController {

    @Autowired
    private ResultService resultService;

    @GetMapping("/results")
    public String resultsPage(
            @RequestParam(required = false) String modelFilter,
            @RequestParam(required = false) String techniqueFilter,
            Model model) {
        
        // Get all results with filters
        List<ExperimentResultDTO> results = resultService.getFilteredResults(modelFilter, techniqueFilter);
        model.addAttribute("results", results);
        
        // Get filter options
        Map<String, List<String>> filterOptions = resultService.getFilterOptions();
        model.addAttribute("models", filterOptions.get("models"));
        model.addAttribute("techniques", filterOptions.get("techniques"));
        
        // Selected filters
        model.addAttribute("selectedModel", modelFilter);
        model.addAttribute("selectedTechnique", techniqueFilter);
        
        // Summary statistics
        model.addAttribute("totalResults", results != null ? results.size() : 0);
        model.addAttribute("totalIngredients", results != null ? resultService.getTotalIngredients(results) : 0);
        
        return "results";
    }
}