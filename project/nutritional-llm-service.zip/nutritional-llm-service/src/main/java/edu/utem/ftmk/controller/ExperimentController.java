package edu.utem.ftmk.controller;

import edu.utem.ftmk.dto.ExperimentDTO;
import edu.utem.ftmk.service.ExperimentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/experiments")
public class ExperimentController {

    @Autowired
    private ExperimentService experimentService;

    @GetMapping
    public ResponseEntity<List<ExperimentDTO>> getAllExperiments() {
        List<ExperimentDTO> experiments = experimentService.getAllExperiments();
        return ResponseEntity.ok(experiments);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ExperimentDTO> getExperimentById(@PathVariable Integer id) {
        ExperimentDTO experiment = experimentService.getExperimentById(id);
        if (experiment == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(experiment);
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<ExperimentDTO>> getByStatus(@PathVariable String status) {
        List<ExperimentDTO> experiments = experimentService.getByStatus(status);
        return ResponseEntity.ok(experiments);
    }

    @GetMapping("/transcript/{transcriptId}")
    public ResponseEntity<List<ExperimentDTO>> getByTranscript(@PathVariable Integer transcriptId) {
        List<ExperimentDTO> experiments = experimentService.getByTranscript(transcriptId);
        return ResponseEntity.ok(experiments);
    }

    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Object>> getStatistics() {
        Map<String, Object> stats = experimentService.getStatistics();
        return ResponseEntity.ok(stats);
    }
}