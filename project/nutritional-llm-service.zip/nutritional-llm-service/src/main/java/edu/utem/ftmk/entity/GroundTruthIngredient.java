package edu.utem.ftmk.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "ground_truth_ingredient")
public class GroundTruthIngredient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "gt_ingredient_id")   // ← primary key column
    private Integer id;

    @Column(name = "gt_reel_id")         // ← this is the transcript ID
    private Integer transcriptId;

    @Column(name = "name_original")      // ← ingredient name
    private String ingredientName;

    // Getters and Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getTranscriptId() { return transcriptId; }
    public void setTranscriptId(Integer transcriptId) { this.transcriptId = transcriptId; }

    public String getIngredientName() { return ingredientName; }
    public void setIngredientName(String ingredientName) { this.ingredientName = ingredientName; }
}