package edu.utem.ftmk.dto;

public class ResultFilterDTO {
    private String model;
    private String technique;

    public ResultFilterDTO() {}

    public ResultFilterDTO(String model, String technique) {
        this.model = model;
        this.technique = technique;
    }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public String getTechnique() { return technique; }
    public void setTechnique(String technique) { this.technique = technique; }
}