package edu.utem.ftmk.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/batch")
public class BatchController {

    @GetMapping
    public String batchPage() {
        return "chat-dashboard";  // Uses the same page with batch mode
    }
}