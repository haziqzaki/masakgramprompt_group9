package edu.utem.ftmk.controller;

import edu.utem.ftmk.entity.NutritionResult;
import edu.utem.ftmk.service.NutritionResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/nutrition")
@CrossOrigin(origins = "*")
public class NutritionController {

    @Autowired
    private NutritionResultService nutritionResultService;

    // Get all nutrition results
    @GetMapping
    public ResponseEntity<List<NutritionResult>> getAllNutritionResults() {
        return ResponseEntity.ok(nutritionResultService.getAllNutritionResults());
    }

    // Get nutrition result by ID
    @GetMapping("/{id}")
    public ResponseEntity<NutritionResult> getNutritionResultById(@PathVariable Integer id) {
        NutritionResult result = nutritionResultService.getNutritionResultById(id);
        if (result != null) {
            return ResponseEntity.ok(result);
        }
        return ResponseEntity.notFound().build();
    }

    // Get nutrition results by experiment
    @GetMapping("/experiment/{experimentId}")
    public ResponseEntity<List<NutritionResult>> getByExperiment(@PathVariable Integer experimentId) {
        return ResponseEntity.ok(nutritionResultService.getByExperiment(experimentId));
    }

    // Get statistics
    @GetMapping("/statistics")
    public ResponseEntity<Map<String, Object>> getStatistics() {
        return ResponseEntity.ok(nutritionResultService.getStatistics());
    }
}	