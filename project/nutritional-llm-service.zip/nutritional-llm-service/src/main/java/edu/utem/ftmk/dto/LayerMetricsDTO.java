package edu.utem.ftmk.dto;

public class LayerMetricsDTO {
    // Layer 1: Text Extraction
    private double exactMatch;
    private double fuzzyF1;
    private double bleu1;
    private double bleu2;
    private double rouge1;
    private double rougeL;
    
    // Layer 2: Numeric Accuracy
    private double quantityMAE;
    private double weightMAE;
    private double caloriesMAPE;
    private double proteinMAPE;
    private double carbsMAPE;
    private double fatMAPE;
    private double pearsonCalories;
    private double pearsonProtein;
    
    // Layer 3: Output Quality
    private double jsonValidityRate;
    private double hallucinationRate;
    private double ingredientPrecision;
    private double ingredientRecall;
    private double ingredientF1;
    
    // Layer 4: Human Evaluation
    private double fluencyScore;
    private double completenessScore;
    private double plausibilityScore;
    private double krippendorffAlpha;
    
    // Layer 5: Statistical Significance
    private double friedmanChiSquare;
    private int wilcoxonPairs;
    private String bestModel;
    private String bestTechnique;

    // Getters and Setters
    public double getExactMatch() { return exactMatch; }
    public void setExactMatch(double exactMatch) { this.exactMatch = exactMatch; }
    
    public double getFuzzyF1() { return fuzzyF1; }
    public void setFuzzyF1(double fuzzyF1) { this.fuzzyF1 = fuzzyF1; }
    
    public double getBleu1() { return bleu1; }
    public void setBleu1(double bleu1) { this.bleu1 = bleu1; }
    
    public double getBleu2() { return bleu2; }
    public void setBleu2(double bleu2) { this.bleu2 = bleu2; }
    
    public double getRouge1() { return rouge1; }
    public void setRouge1(double rouge1) { this.rouge1 = rouge1; }
    
    public double getRougeL() { return rougeL; }
    public void setRougeL(double rougeL) { this.rougeL = rougeL; }
    
    public double getQuantityMAE() { return quantityMAE; }
    public void setQuantityMAE(double quantityMAE) { this.quantityMAE = quantityMAE; }
    
    public double getWeightMAE() { return weightMAE; }
    public void setWeightMAE(double weightMAE) { this.weightMAE = weightMAE; }
    
    public double getCaloriesMAPE() { return caloriesMAPE; }
    public void setCaloriesMAPE(double caloriesMAPE) { this.caloriesMAPE = caloriesMAPE; }
    
    public double getProteinMAPE() { return proteinMAPE; }
    public void setProteinMAPE(double proteinMAPE) { this.proteinMAPE = proteinMAPE; }
    
    public double getCarbsMAPE() { return carbsMAPE; }
    public void setCarbsMAPE(double carbsMAPE) { this.carbsMAPE = carbsMAPE; }
    
    public double getFatMAPE() { return fatMAPE; }
    public void setFatMAPE(double fatMAPE) { this.fatMAPE = fatMAPE; }
    
    public double getPearsonCalories() { return pearsonCalories; }
    public void setPearsonCalories(double pearsonCalories) { this.pearsonCalories = pearsonCalories; }
    
    public double getPearsonProtein() { return pearsonProtein; }
    public void setPearsonProtein(double pearsonProtein) { this.pearsonProtein = pearsonProtein; }
    
    public double getJsonValidityRate() { return jsonValidityRate; }
    public void setJsonValidityRate(double jsonValidityRate) { this.jsonValidityRate = jsonValidityRate; }
    
    public double getHallucinationRate() { return hallucinationRate; }
    public void setHallucinationRate(double hallucinationRate) { this.hallucinationRate = hallucinationRate; }
    
    public double getIngredientPrecision() { return ingredientPrecision; }
    public void setIngredientPrecision(double ingredientPrecision) { this.ingredientPrecision = ingredientPrecision; }
    
    public double getIngredientRecall() { return ingredientRecall; }
    public void setIngredientRecall(double ingredientRecall) { this.ingredientRecall = ingredientRecall; }
    
    public double getIngredientF1() { return ingredientF1; }
    public void setIngredientF1(double ingredientF1) { this.ingredientF1 = ingredientF1; }
    
    public double getFluencyScore() { return fluencyScore; }
    public void setFluencyScore(double fluencyScore) { this.fluencyScore = fluencyScore; }
    
    public double getCompletenessScore() { return completenessScore; }
    public void setCompletenessScore(double completenessScore) { this.completenessScore = completenessScore; }
    
    public double getPlausibilityScore() { return plausibilityScore; }
    public void setPlausibilityScore(double plausibilityScore) { this.plausibilityScore = plausibilityScore; }
    
    public double getKrippendorffAlpha() { return krippendorffAlpha; }
    public void setKrippendorffAlpha(double krippendorffAlpha) { this.krippendorffAlpha = krippendorffAlpha; }
    
    public double getFriedmanChiSquare() { return friedmanChiSquare; }
    public void setFriedmanChiSquare(double friedmanChiSquare) { this.friedmanChiSquare = friedmanChiSquare; }
    
    public int getWilcoxonPairs() { return wilcoxonPairs; }
    public void setWilcoxonPairs(int wilcoxonPairs) { this.wilcoxonPairs = wilcoxonPairs; }
    
    public String getBestModel() { return bestModel; }
    public void setBestModel(String bestModel) { this.bestModel = bestModel; }
    
    public String getBestTechnique() { return bestTechnique; }
    public void setBestTechnique(String bestTechnique) { this.bestTechnique = bestTechnique; }
}