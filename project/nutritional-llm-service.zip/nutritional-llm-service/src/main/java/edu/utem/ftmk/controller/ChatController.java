package edu.utem.ftmk.controller;

import edu.utem.ftmk.dto.ChatRequest;
import edu.utem.ftmk.dto.ChatResponse;
import edu.utem.ftmk.service.LLMService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import java.sql.*;
import java.util.*;

@Controller
public class ChatController {

    @Autowired
    private LLMService llmService;

    private static final String DB_URL = "jdbc:mysql://localhost:3306/masakgramprompt?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kuala_Lumpur";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    @GetMapping("/chat")
    public String chatPage(Model model) {
        // Add model list for the dropdown
        Map<String, String> models = new LinkedHashMap<>();
        models.put("llama3.2:3b", "Llama 3.2 3B");
        models.put("phi4-mini", "Phi-4-mini");
        models.put("qwen2.5:3b", "Qwen 2.5 3B");
        models.put("aisingapore/Gemma-SEA-LION-v4-4B-VL", "Gemma-SEA-LION");
        models.put("medgemma:4b", "MedGemma 4B");
        model.addAttribute("models", models);
        
        return "chat";
    }

    @PostMapping("/api/chat/send")
    @ResponseBody
    public ChatResponse sendMessage(@RequestBody ChatRequest request) {
        try {
            String response = llmService.prompt(request.getModelName(), request.getPrompt());
            return new ChatResponse(response, request.getModelName(), "success");
        } catch (Exception e) {
            return new ChatResponse("Error: " + e.getMessage(), request.getModelName(), "error");
        }
    }

    @GetMapping("/api/chat/models")
    @ResponseBody
    public Map<String, Object> getModels() {
        Map<String, Object> response = new HashMap<>();
        Map<String, String> models = new LinkedHashMap<>();
        models.put("llama3.2:3b", "Llama 3.2 3B");
        models.put("phi4-mini", "Phi-4-mini");
        models.put("qwen2.5:3b", "Qwen 2.5 3B");
        models.put("aisingapore/Gemma-SEA-LION-v4-4B-VL", "Gemma-SEA-LION");
        models.put("medgemma:4b", "MedGemma 4B");
        
        Map<String, String> techniques = new LinkedHashMap<>();
        techniques.put("zero-shot", "Zero-Shot");
        techniques.put("few-shot", "Few-Shot");
        techniques.put("chain-of-thought", "Chain of Thought");
        techniques.put("structured-output", "Structured Output");
        
        response.put("models", models);
        response.put("techniques", techniques);
        return response;
    }

    @GetMapping("/api/transcripts")
    @ResponseBody
    public List<Map<String, Object>> getTranscripts() {
        List<Map<String, Object>> transcripts = new ArrayList<>();
        // Read from file_path instead of content
        String sql = "SELECT transcript_id, file_path FROM transcript ORDER BY transcript_id";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Map<String, Object> t = new HashMap<>();
                int transcriptId = rs.getInt("transcript_id");
                String filePath = rs.getString("file_path");
                
                t.put("transcript_id", transcriptId);
                
                // Read content from file
                if (filePath != null && !filePath.isEmpty()) {
                    try {
                        String fixedPath = filePath.replace("\\", "/");
                        java.nio.file.Path path = java.nio.file.Paths.get(fixedPath);
                        if (java.nio.file.Files.exists(path)) {
                            String content = new String(java.nio.file.Files.readAllBytes(path), 
                                                        java.nio.charset.StandardCharsets.UTF_8);
                            t.put("content", content);
                        } else {
                            t.put("content", "File not found: " + filePath);
                        }
                    } catch (Exception e) {
                        t.put("content", "Error reading file: " + e.getMessage());
                    }
                } else {
                    t.put("content", "No file path available");
                }
                
                transcripts.add(t);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transcripts;
    }
}