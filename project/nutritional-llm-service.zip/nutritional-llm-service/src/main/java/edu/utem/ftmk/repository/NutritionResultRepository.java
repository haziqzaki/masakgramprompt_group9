package edu.utem.ftmk.repository;

import edu.utem.ftmk.entity.NutritionResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface NutritionResultRepository extends JpaRepository<NutritionResult, Integer> {
    
    List<NutritionResult> findByExperimentId(Integer experimentId);
    
    List<NutritionResult> findByJsonValid(Boolean jsonValid);
    
    @Query("SELECT COUNT(n) FROM NutritionResult n WHERE n.jsonValid = true")
    long countValidJson();
    
    @Query("SELECT COUNT(n) FROM NutritionResult n WHERE n.jsonValid = false OR n.jsonValid IS NULL")
    long countInvalidJson();
}