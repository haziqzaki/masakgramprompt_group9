package edu.utem.ftmk.service;

import edu.utem.ftmk.entity.NutritionResult;
import edu.utem.ftmk.repository.NutritionResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

@Service
public class NutritionResultService {

    @Autowired
    private NutritionResultRepository nutritionResultRepository;

    public List<NutritionResult> getAllNutritionResults() {
        return nutritionResultRepository.findAll();
    }

    public NutritionResult getNutritionResultById(Integer id) {
        return nutritionResultRepository.findById(id).orElse(null);
    }

    public List<NutritionResult> getByExperiment(Integer experimentId) {
        return nutritionResultRepository.findByExperimentId(experimentId);
    }

    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("total", nutritionResultRepository.count());
        stats.put("validJson", nutritionResultRepository.countValidJson());
        stats.put("invalidJson", nutritionResultRepository.countInvalidJson());
        return stats;
    }
}