package edu.utem.ftmk.service;

import edu.utem.ftmk.dto.ExperimentDTO;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.*;

@Service
public class ExperimentService {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/masakgramprompt?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kuala_Lumpur";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    // ============================================================
    // GET ALL EXPERIMENTS
    // ============================================================

    public List<ExperimentDTO> getAllExperiments() {
        List<ExperimentDTO> experiments = new ArrayList<>();
        String sql = "SELECT e.experiment_id, e.transcript_id, m.model_name, " +
                     "p.technique_name, e.status, e.executed_at, e.rag_enabled " +
                     "FROM experiment e " +
                     "JOIN llm_model m ON e.model_id = m.model_id " +
                     "JOIN prompt_technique p ON e.technique_id = p.technique_id " +
                     "ORDER BY e.experiment_id DESC";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                ExperimentDTO dto = new ExperimentDTO();
                dto.setExperimentId(rs.getInt("experiment_id"));
                dto.setTranscriptId(rs.getInt("transcript_id"));
                dto.setModelName(rs.getString("model_name"));
                dto.setTechniqueName(rs.getString("technique_name"));
                dto.setStatus(rs.getString("status"));
                dto.setExecutedAt(rs.getTimestamp("executed_at"));
                dto.setRagEnabled(rs.getBoolean("rag_enabled"));
                experiments.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return experiments;
    }

    // ============================================================
    // GET BY ID
    // ============================================================

    public ExperimentDTO getExperimentById(Integer id) {
        String sql = "SELECT e.experiment_id, e.transcript_id, m.model_name, " +
                     "p.technique_name, e.status, e.executed_at, e.rag_enabled " +
                     "FROM experiment e " +
                     "JOIN llm_model m ON e.model_id = m.model_id " +
                     "JOIN prompt_technique p ON e.technique_id = p.technique_id " +
                     "WHERE e.experiment_id = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                ExperimentDTO dto = new ExperimentDTO();
                dto.setExperimentId(rs.getInt("experiment_id"));
                dto.setTranscriptId(rs.getInt("transcript_id"));
                dto.setModelName(rs.getString("model_name"));
                dto.setTechniqueName(rs.getString("technique_name"));
                dto.setStatus(rs.getString("status"));
                dto.setExecutedAt(rs.getTimestamp("executed_at"));
                dto.setRagEnabled(rs.getBoolean("rag_enabled"));
                return dto;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // ============================================================
    // GET BY STATUS
    // ============================================================

    public List<ExperimentDTO> getByStatus(String status) {
        List<ExperimentDTO> experiments = new ArrayList<>();
        String sql = "SELECT e.experiment_id, e.transcript_id, m.model_name, " +
                     "p.technique_name, e.status, e.executed_at, e.rag_enabled " +
                     "FROM experiment e " +
                     "JOIN llm_model m ON e.model_id = m.model_id " +
                     "JOIN prompt_technique p ON e.technique_id = p.technique_id " +
                     "WHERE e.status = ? " +
                     "ORDER BY e.executed_at DESC";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                ExperimentDTO dto = new ExperimentDTO();
                dto.setExperimentId(rs.getInt("experiment_id"));
                dto.setTranscriptId(rs.getInt("transcript_id"));
                dto.setModelName(rs.getString("model_name"));
                dto.setTechniqueName(rs.getString("technique_name"));
                dto.setStatus(rs.getString("status"));
                dto.setExecutedAt(rs.getTimestamp("executed_at"));
                dto.setRagEnabled(rs.getBoolean("rag_enabled"));
                experiments.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return experiments;
    }

    // ============================================================
    // GET BY TRANSCRIPT
    // ============================================================

    public List<ExperimentDTO> getByTranscript(Integer transcriptId) {
        List<ExperimentDTO> experiments = new ArrayList<>();
        String sql = "SELECT e.experiment_id, e.transcript_id, m.model_name, " +
                     "p.technique_name, e.status, e.executed_at, e.rag_enabled " +
                     "FROM experiment e " +
                     "JOIN llm_model m ON e.model_id = m.model_id " +
                     "JOIN prompt_technique p ON e.technique_id = p.technique_id " +
                     "WHERE e.transcript_id = ? " +
                     "ORDER BY e.executed_at DESC";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transcriptId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                ExperimentDTO dto = new ExperimentDTO();
                dto.setExperimentId(rs.getInt("experiment_id"));
                dto.setTranscriptId(rs.getInt("transcript_id"));
                dto.setModelName(rs.getString("model_name"));
                dto.setTechniqueName(rs.getString("technique_name"));
                dto.setStatus(rs.getString("status"));
                dto.setExecutedAt(rs.getTimestamp("executed_at"));
                dto.setRagEnabled(rs.getBoolean("rag_enabled"));
                experiments.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return experiments;
    }

    // ============================================================
    // GET RECENT EXPERIMENTS
    // ============================================================

    public List<ExperimentDTO> getRecentExperiments() {
        return getByStatus("completed");
    }

    // ============================================================
    // STATISTICS
    // ============================================================

    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalExperiments", getTotalExperiments());
        stats.put("completedExperiments", getCompletedExperiments());
        stats.put("pendingExperiments", getPendingExperiments());
        stats.put("failedExperiments", getFailedExperiments());
        stats.put("totalNutritionResults", getTotalNutritionResults());
        stats.put("totalIngredients", getTotalIngredients());
        return stats;
    }

    // ============================================================
    // COUNTERS
    // ============================================================

    public int getTotalExperiments() {
        String sql = "SELECT COUNT(*) FROM experiment";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getCompletedExperiments() {
        String sql = "SELECT COUNT(*) FROM experiment WHERE status = 'completed'";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getPendingExperiments() {
        String sql = "SELECT COUNT(*) FROM experiment WHERE status = 'pending'";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getFailedExperiments() {
        String sql = "SELECT COUNT(*) FROM experiment WHERE status = 'failed'";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getTotalNutritionResults() {
        String sql = "SELECT COUNT(*) FROM nutrition_result";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getTotalIngredients() {
        String sql = "SELECT COUNT(*) FROM ingredient_result";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}