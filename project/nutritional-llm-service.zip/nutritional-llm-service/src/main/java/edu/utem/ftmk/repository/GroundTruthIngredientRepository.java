package edu.utem.ftmk.repository;

import edu.utem.ftmk.entity.GroundTruthIngredient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface GroundTruthIngredientRepository extends JpaRepository<GroundTruthIngredient, Integer> {
    List<GroundTruthIngredient> findByTranscriptId(Integer transcriptId);
}