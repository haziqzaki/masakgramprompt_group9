package edu.utem.ftmk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"edu.utem.ftmk"})
public class NutritionalLlmApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(NutritionalLlmApplication.class, args);
        
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║                                                            ║");
        System.out.println("║   🍳 Nutritional LLM Service Started Successfully!         ║");
        System.out.println("║                                                            ║");
        System.out.println("║   📊 Dashboard:   http://localhost:8080/dashboard          ║");
        System.out.println("║   🔬 API:         http://localhost:8080/api/experiments    ║");
        System.out.println("║   📈 Statistics:  http://localhost:8080/api/experiments/statistics ║");
        System.out.println("║                                                            ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");
    }
}