package edu.utem.ftmk.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;  // ← IMPORT FOR LocalDateTime

@Entity
@Table(name = "nutrition_result")
public class NutritionResult {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "result_id")
    private Integer resultId;
    
    @Column(name = "experiment_id")
    private Integer experimentId;
    
    @Column(name = "recipe_name")
    private String recipeName;
    
    @Column(name = "servings_estimated")
    private Integer servingsEstimated;
    
    @Column(name = "serving_calories")
    private Double servingCalories;
    
    @Column(name = "serving_total_fat_g")
    private Double servingTotalFatG;
    
    @Column(name = "serving_protein_g")
    private Double servingProteinG;
    
    @Column(name = "serving_total_carbohydrate_g")
    private Double servingTotalCarbohydrateG;
    
    @Column(name = "total_calories")
    private Double totalCalories;
    
    @Column(name = "total_fat_g")
    private Double totalFatG;
    
    @Column(name = "total_protein_g")
    private Double totalProteinG;
    
    @Column(name = "total_carbohydrate_g")
    private Double totalCarbohydrateG;
    
    @Column(name = "raw_json_output", columnDefinition = "TEXT")
    private String rawJsonOutput;
    
    @Column(name = "json_valid")
    private Boolean jsonValid;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;  // ← Now works with import

    // Getters and Setters
    public Integer getResultId() { return resultId; }
    public void setResultId(Integer resultId) { this.resultId = resultId; }
    
    public Integer getExperimentId() { return experimentId; }
    public void setExperimentId(Integer experimentId) { this.experimentId = experimentId; }
    
    public String getRecipeName() { return recipeName; }
    public void setRecipeName(String recipeName) { this.recipeName = recipeName; }
    
    public Integer getServingsEstimated() { return servingsEstimated; }
    public void setServingsEstimated(Integer servingsEstimated) { this.servingsEstimated = servingsEstimated; }
    
    public Double getServingCalories() { return servingCalories; }
    public void setServingCalories(Double servingCalories) { this.servingCalories = servingCalories; }
    
    public Double getServingTotalFatG() { return servingTotalFatG; }
    public void setServingTotalFatG(Double servingTotalFatG) { this.servingTotalFatG = servingTotalFatG; }
    
    public Double getServingProteinG() { return servingProteinG; }
    public void setServingProteinG(Double servingProteinG) { this.servingProteinG = servingProteinG; }
    
    public Double getServingTotalCarbohydrateG() { return servingTotalCarbohydrateG; }
    public void setServingTotalCarbohydrateG(Double servingTotalCarbohydrateG) { this.servingTotalCarbohydrateG = servingTotalCarbohydrateG; }
    
    public Double getTotalCalories() { return totalCalories; }
    public void setTotalCalories(Double totalCalories) { this.totalCalories = totalCalories; }
    
    public Double getTotalFatG() { return totalFatG; }
    public void setTotalFatG(Double totalFatG) { this.totalFatG = totalFatG; }
    
    public Double getTotalProteinG() { return totalProteinG; }
    public void setTotalProteinG(Double totalProteinG) { this.totalProteinG = totalProteinG; }
    
    public Double getTotalCarbohydrateG() { return totalCarbohydrateG; }
    public void setTotalCarbohydrateG(Double totalCarbohydrateG) { this.totalCarbohydrateG = totalCarbohydrateG; }
    
    public String getRawJsonOutput() { return rawJsonOutput; }
    public void setRawJsonOutput(String rawJsonOutput) { this.rawJsonOutput = rawJsonOutput; }
    
    public Boolean getJsonValid() { return jsonValid; }
    public void setJsonValid(Boolean jsonValid) { this.jsonValid = jsonValid; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}