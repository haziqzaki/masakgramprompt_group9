package edu.utem.ftmk.llm;

import com.google.gson.*;
import com.google.gson.stream.JsonReader;

import java.sql.*;
import java.util.*;
import java.io.StringReader;

public class IngredientFixRunner {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/nutritional_llm?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kuala_Lumpur";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        IngredientFixRunner runner = new IngredientFixRunner();
        runner.fixIngredientResults();
    }

    public void fixIngredientResults() {
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║     🔧 LENIENT JSON PARSER WITH CLEANING                 ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");

        int deleted = deleteExistingIngredients();
        System.out.println("✅ Deleted " + deleted + " existing ingredient records");

        List<NutritionResultData> results = getNutritionResults();
        System.out.println("📊 Found " + results.size() + " nutrition results to process\n");

        int success = 0;
        int totalIngredients = 0;

        for (NutritionResultData data : results) {
            try {
                System.out.print("Processing experiment_id: " + data.experimentId + " ... ");
                
                int count = parseAndInsertIngredientsWithCleaning(data.resultId, data.jsonOutput);
                
                if (count > 0) {
                    System.out.println("✅ Inserted " + count + " ingredients");
                    success++;
                    totalIngredients += count;
                } else {
                    System.out.println("⚠️ No ingredients found");
                    success++;
                }
                
            } catch (Exception e) {
                System.out.println("❌ FAILED: " + e.getMessage());
            }
        }

        System.out.println("\n=====================================");
        System.out.println("✅ FIX COMPLETE!");
        System.out.println("   Success   : " + success);
        System.out.println("   Total Ingredients Inserted: " + totalIngredients);
        System.out.println("=====================================");
    }

    private int deleteExistingIngredients() {
        String sql = "DELETE FROM ingredient_result";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {
            return stmt.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private List<NutritionResultData> getNutritionResults() {
        List<NutritionResultData> results = new ArrayList<>();
        String sql = "SELECT result_id, experiment_id, raw_json_output FROM nutrition_result WHERE raw_json_output IS NOT NULL";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                NutritionResultData data = new NutritionResultData();
                data.resultId = rs.getInt("result_id");
                data.experimentId = rs.getInt("experiment_id");
                data.jsonOutput = rs.getString("raw_json_output");
                results.add(data);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return results;
    }

    /**
     * Cleans the raw JSON response by removing markdown, prose, and extracting only the JSON portion.
     */
    private String cleanJsonResponse(String raw) {
        if (raw == null || raw.isEmpty()) return null;
        
        // Remove markdown code blocks (```json ... ```)
        String cleaned = raw.replaceAll("(?s)```json\\s*", "");
        cleaned = cleaned.replaceAll("(?s)```\\s*", "");
        
        // Remove any leading text before the first '{'
        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        
        if (start >= 0 && end > start) {
            return cleaned.substring(start, end + 1).trim();
        }
        
        // Try to find JSON array if object not found
        start = cleaned.indexOf('[');
        end = cleaned.lastIndexOf(']');
        if (start >= 0 && end > start) {
            return cleaned.substring(start, end + 1).trim();
        }
        
        return null;
    }

    private int parseAndInsertIngredientsWithCleaning(int nutritionResultId, String jsonResponse) {
        int count = 0;
        
        try {
            // Step 1: Clean the response
            String cleanedJson = cleanJsonResponse(jsonResponse);
            if (cleanedJson == null) {
                return 0;
            }
            
            // Step 2: Parse with lenient mode
            JsonReader reader = new JsonReader(new StringReader(cleanedJson));
            reader.setLenient(true);
            
            JsonElement rootElement = JsonParser.parseReader(reader);
            if (!rootElement.isJsonObject()) {
                return 0;
            }
            
            JsonObject root = rootElement.getAsJsonObject();
            
            // Step 3: Find ingredients
            JsonArray ingredients = null;
            
            // Try different possible field names
            String[] possibleArrayNames = {"ingredients", "ingredient", "items", "data"};
            for (String name : possibleArrayNames) {
                if (root.has(name)) {
                    try {
                        ingredients = root.getAsJsonArray(name);
                        break;
                    } catch (Exception e) {
                        // Not an array, try as object
                        try {
                            JsonObject ingObj = root.getAsJsonObject(name);
                            if (ingObj != null) {
                                ingredients = new JsonArray();
                                ingredients.add(ingObj);
                                break;
                            }
                        } catch (Exception e2) {
                            // Try to get as string and parse
                            try {
                                String str = root.get(name).getAsString();
                                if (str != null && !str.isEmpty()) {
                                    JsonReader strReader = new JsonReader(new StringReader(str));
                                    strReader.setLenient(true);
                                    JsonElement el = JsonParser.parseReader(strReader);
                                    if (el.isJsonArray()) {
                                        ingredients = el.getAsJsonArray();
                                        break;
                                    }
                                }
                            } catch (Exception e3) {
                                // Ignore
                            }
                        }
                    }
                }
            }
            
            if (ingredients == null || ingredients.size() == 0) {
                return 0;
            }
            
            // Step 4: Insert ingredients
            String sql = "INSERT INTO ingredient_result (" +
                "result_id, name_original, name_en, quantity_value, " +
                "unit_original, unit_en, estimated_weight_g, " +
                "calories, total_fat_g, saturated_fat_g, cholesterol_mg, " +
                "sodium_mg, total_carbohydrate_g, dietary_fiber_g, " +
                "total_sugars_g, protein_g, vitamin_d_mcg, calcium_mg, iron_mg, potassium_mg" +
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                
                for (JsonElement element : ingredients) {
                    JsonObject ing = element.getAsJsonObject();
                    
                    pstmt.setInt(1, nutritionResultId);
                    pstmt.setString(2, getStringLenient(ing, "ingredient_name_original"));
                    pstmt.setString(3, getStringLenient(ing, "ingredient_name_en"));
                    pstmt.setDouble(4, getDoubleLenient(ing, "quantity_value"));
                    pstmt.setString(5, getStringLenient(ing, "quantity_unit_original"));
                    pstmt.setString(6, getStringLenient(ing, "quantity_unit_en"));
                    pstmt.setDouble(7, getDoubleLenient(ing, "estimated_weight_g"));
                    pstmt.setDouble(8, getDoubleLenient(ing, "calories"));
                    pstmt.setDouble(9, getDoubleLenient(ing, "total_fat_g"));
                    pstmt.setDouble(10, getDoubleLenient(ing, "saturated_fat_g"));
                    pstmt.setDouble(11, getDoubleLenient(ing, "cholesterol_mg"));
                    pstmt.setDouble(12, getDoubleLenient(ing, "sodium_mg"));
                    pstmt.setDouble(13, getDoubleLenient(ing, "total_carbohydrate_g"));
                    pstmt.setDouble(14, getDoubleLenient(ing, "dietary_fiber_g"));
                    pstmt.setDouble(15, getDoubleLenient(ing, "total_sugars_g"));
                    pstmt.setDouble(16, getDoubleLenient(ing, "protein_g"));
                    pstmt.setDouble(17, getDoubleLenient(ing, "vitamin_d_mcg"));
                    pstmt.setDouble(18, getDoubleLenient(ing, "calcium_mg"));
                    pstmt.setDouble(19, getDoubleLenient(ing, "iron_mg"));
                    pstmt.setDouble(20, getDoubleLenient(ing, "potassium_mg"));
                    pstmt.addBatch();
                    count++;
                }
                pstmt.executeBatch();
            }
            
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
        
        return count;
    }

    private String getStringLenient(JsonObject obj, String key) {
        String[] alternatives = {
            key, "ingredient_name_original", "ingredient_name_en", "name_original", 
            "name_en", "ingredient", "name", "item", "original_name", "english_name",
            "ingredient_name", "original", "en"
        };
        for (String alt : alternatives) {
            if (obj.has(alt) && !obj.get(alt).isJsonNull()) {
                try {
                    return obj.get(alt).getAsString();
                } catch (Exception e) {
                    // Try to get as string from JsonPrimitive
                    try {
                        return obj.get(alt).toString().replaceAll("^\"|\"$", "");
                    } catch (Exception e2) {
                        continue;
                    }
                }
            }
        }
        return null;
    }

    private double getDoubleLenient(JsonObject obj, String key) {
        String[] alternatives = {
            key, "quantity_value", "estimated_weight_g", "qty", "amount", "quantity", "weight",
            "weight_g", "value", "num", "count"
        };
        for (String alt : alternatives) {
            if (obj.has(alt) && !obj.get(alt).isJsonNull()) {
                try {
                    return obj.get(alt).getAsDouble();
                } catch (Exception e) {
                    // Try to parse as string
                    try {
                        String val = obj.get(alt).getAsString();
                        // Handle fractions like "3/4"
                        if (val.contains("/")) {
                            String[] parts = val.split("/");
                            if (parts.length == 2) {
                                double num = Double.parseDouble(parts[0].trim());
                                double den = Double.parseDouble(parts[1].trim());
                                if (den != 0) {
                                    return num / den;
                                }
                            }
                        }
                        // Remove non-numeric characters
                        val = val.replaceAll("[^0-9.]", "");
                        if (!val.isEmpty()) {
                            return Double.parseDouble(val);
                        }
                    } catch (Exception e2) {
                        continue;
                    }
                }
            }
        }
        return 0.0;
    }

    private static class NutritionResultData {
        int resultId;
        int experimentId;
        String jsonOutput;
    }
}