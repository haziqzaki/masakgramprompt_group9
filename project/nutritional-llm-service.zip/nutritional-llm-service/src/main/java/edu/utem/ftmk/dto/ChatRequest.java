package edu.utem.ftmk.dto;

public class ChatRequest {
    private String modelName;
    private String prompt;
    private String technique;

    public ChatRequest() {}

    public ChatRequest(String modelName, String prompt, String technique) {
        this.modelName = modelName;
        this.prompt = prompt;
        this.technique = technique;
    }

    public String getModelName() { return modelName; }
    public void setModelName(String modelName) { this.modelName = modelName; }

    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }

    public String getTechnique() { return technique; }
    public void setTechnique(String technique) { this.technique = technique; }
}