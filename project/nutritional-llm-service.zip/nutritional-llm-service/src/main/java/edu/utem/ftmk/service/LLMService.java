package edu.utem.ftmk.service;

import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.ollama.OllamaChatModel;
import org.springframework.stereotype.Service;

import java.time.Duration;

@Service
public class LLMService {

    private static final String OLLAMA_BASE_URL = "http://localhost:11434";

    public String prompt(String modelName, String userPrompt) {
        try {
            ChatModel model = OllamaChatModel.builder()
                    .baseUrl(OLLAMA_BASE_URL)
                    .modelName(modelName)
                    .timeout(Duration.ofMinutes(5))
                    .build();
            return model.chat(userPrompt);
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}