package edu.utem.ftmk.dto;

public class StatisticsDTO {
    private int totalExperiments;
    private int completedExperiments;
    private int pendingExperiments;
    private int failedExperiments;
    private int totalNutritionResults;
    private int totalIngredients;

    public StatisticsDTO() {}

    public int getTotalExperiments() { return totalExperiments; }
    public void setTotalExperiments(int totalExperiments) { this.totalExperiments = totalExperiments; }
    
    public int getCompletedExperiments() { return completedExperiments; }
    public void setCompletedExperiments(int completedExperiments) { this.completedExperiments = completedExperiments; }
    
    public int getPendingExperiments() { return pendingExperiments; }
    public void setPendingExperiments(int pendingExperiments) { this.pendingExperiments = pendingExperiments; }
    
    public int getFailedExperiments() { return failedExperiments; }
    public void setFailedExperiments(int failedExperiments) { this.failedExperiments = failedExperiments; }
    
    public int getTotalNutritionResults() { return totalNutritionResults; }
    public void setTotalNutritionResults(int totalNutritionResults) { this.totalNutritionResults = totalNutritionResults; }
    
    public int getTotalIngredients() { return totalIngredients; }
    public void setTotalIngredients(int totalIngredients) { this.totalIngredients = totalIngredients; }
}