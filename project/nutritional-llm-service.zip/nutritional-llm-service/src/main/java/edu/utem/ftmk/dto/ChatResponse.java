package edu.utem.ftmk.dto;

public class ChatResponse {
    private String response;
    private String model;
    private String status;

    public ChatResponse() {}

    public ChatResponse(String response, String model, String status) {
        this.response = response;
        this.model = model;
        this.status = status;
    }

    public String getResponse() { return response; }
    public void setResponse(String response) { this.response = response; }

    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}