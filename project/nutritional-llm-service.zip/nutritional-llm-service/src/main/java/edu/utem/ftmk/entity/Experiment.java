package edu.utem.ftmk.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "experiment")
public class Experiment {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "experiment_id")
    private Integer experimentId;
    
    @Column(name = "transcript_id")
    private Integer transcriptId;
    
    @Column(name = "model_id")
    private Integer modelId;
    
    @Column(name = "technique_id")
    private Integer techniqueId;
    
    @Column(name = "rag_enabled")
    private Boolean ragEnabled = false;
    
    @Column(name = "status")
    private String status = "pending";
    
    @Column(name = "executed_at")
    private LocalDateTime executedAt;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    // Getters and Setters
    public Integer getExperimentId() { return experimentId; }
    public void setExperimentId(Integer experimentId) { this.experimentId = experimentId; }
    
    public Integer getTranscriptId() { return transcriptId; }
    public void setTranscriptId(Integer transcriptId) { this.transcriptId = transcriptId; }
    
    public Integer getModelId() { return modelId; }
    public void setModelId(Integer modelId) { this.modelId = modelId; }
    
    public Integer getTechniqueId() { return techniqueId; }
    public void setTechniqueId(Integer techniqueId) { this.techniqueId = techniqueId; }
    
    public Boolean getRagEnabled() { return ragEnabled; }
    public void setRagEnabled(Boolean ragEnabled) { this.ragEnabled = ragEnabled; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public LocalDateTime getExecutedAt() { return executedAt; }
    public void setExecutedAt(LocalDateTime executedAt) { this.executedAt = executedAt; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}