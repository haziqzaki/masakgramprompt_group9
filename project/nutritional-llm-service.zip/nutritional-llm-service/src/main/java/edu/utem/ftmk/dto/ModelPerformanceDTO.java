package edu.utem.ftmk.dto;

public class ModelPerformanceDTO {
    private String modelName;
    private double zeroShot;
    private double fewShot;
    private double chainOfThought;
    private double structuredOutput;
    private double avgSuccess;

    public ModelPerformanceDTO() {}

    public ModelPerformanceDTO(String modelName, double zeroShot, double fewShot, 
                               double chainOfThought, double structuredOutput, double avgSuccess) {
        this.modelName = modelName;
        this.zeroShot = zeroShot;
        this.fewShot = fewShot;
        this.chainOfThought = chainOfThought;
        this.structuredOutput = structuredOutput;
        this.avgSuccess = avgSuccess;
    }

    public String getModelName() { return modelName; }
    public void setModelName(String modelName) { this.modelName = modelName; }
    
    public double getZeroShot() { return zeroShot; }
    public void setZeroShot(double zeroShot) { this.zeroShot = zeroShot; }
    
    public double getFewShot() { return fewShot; }
    public void setFewShot(double fewShot) { this.fewShot = fewShot; }
    
    public double getChainOfThought() { return chainOfThought; }
    public void setChainOfThought(double chainOfThought) { this.chainOfThought = chainOfThought; }
    
    public double getStructuredOutput() { return structuredOutput; }
    public void setStructuredOutput(double structuredOutput) { this.structuredOutput = structuredOutput; }
    
    public double getAvgSuccess() { return avgSuccess; }
    public void setAvgSuccess(double avgSuccess) { this.avgSuccess = avgSuccess; }
}