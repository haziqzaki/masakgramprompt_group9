package edu.utem.ftmk.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class ExperimentResultDTO {
    private int experimentId;
    private int transcriptId;
    private String transcriptPreview;
    private String modelName;
    private String techniqueName;
    private String status;
    private String recipeName;
    private int servingsEstimated;
    private double totalCalories;
    private double totalProtein;
    private double totalFat;
    private double totalCarbs;
    private int ingredientCount;
    private int hallucinatedCount;
    private Timestamp executedAt;
    private String rawJson;
    private List<IngredientResultDTO> ingredients;
    private List<String> groundTruthIngredients = new ArrayList<>();
    private String groundTruthJson;   // <-- NEW FIELD (JSON string for ground truth)

    // Default Constructor
    public ExperimentResultDTO() {}

    // Getters
    public int getExperimentId() { return experimentId; }
    public int getTranscriptId() { return transcriptId; }
    public String getTranscriptPreview() { return transcriptPreview; }
    public String getModelName() { return modelName; }
    public String getTechniqueName() { return techniqueName; }
    public String getStatus() { return status; }
    public String getRecipeName() { return recipeName; }
    public int getServingsEstimated() { return servingsEstimated; }
    public double getTotalCalories() { return totalCalories; }
    public double getTotalProtein() { return totalProtein; }
    public double getTotalFat() { return totalFat; }
    public double getTotalCarbs() { return totalCarbs; }
    public int getIngredientCount() { return ingredientCount; }
    public int getHallucinatedCount() { return hallucinatedCount; }
    public Timestamp getExecutedAt() { return executedAt; }
    public String getRawJson() { return rawJson; }
    public List<IngredientResultDTO> getIngredients() { return ingredients; }
    public List<String> getGroundTruthIngredients() { return groundTruthIngredients; }
    public String getGroundTruthJson() { return groundTruthJson; }   // <-- NEW GETTER

    // Setters
    public void setExperimentId(int experimentId) { this.experimentId = experimentId; }
    public void setTranscriptId(int transcriptId) { this.transcriptId = transcriptId; }
    public void setTranscriptPreview(String transcriptPreview) { this.transcriptPreview = transcriptPreview; }
    public void setModelName(String modelName) { this.modelName = modelName; }
    public void setTechniqueName(String techniqueName) { this.techniqueName = techniqueName; }
    public void setStatus(String status) { this.status = status; }
    public void setRecipeName(String recipeName) { this.recipeName = recipeName; }
    public void setServingsEstimated(int servingsEstimated) { this.servingsEstimated = servingsEstimated; }
    public void setTotalCalories(double totalCalories) { this.totalCalories = totalCalories; }
    public void setTotalProtein(double totalProtein) { this.totalProtein = totalProtein; }
    public void setTotalFat(double totalFat) { this.totalFat = totalFat; }
    public void setTotalCarbs(double totalCarbs) { this.totalCarbs = totalCarbs; }
    public void setIngredientCount(int ingredientCount) { this.ingredientCount = ingredientCount; }
    public void setHallucinatedCount(int hallucinatedCount) { this.hallucinatedCount = hallucinatedCount; }
    public void setExecutedAt(Timestamp executedAt) { this.executedAt = executedAt; }
    public void setRawJson(String rawJson) { this.rawJson = rawJson; }
    public void setIngredients(List<IngredientResultDTO> ingredients) { this.ingredients = ingredients; }
    public void setGroundTruthIngredients(List<String> groundTruthIngredients) { this.groundTruthIngredients = groundTruthIngredients; }
    public void setGroundTruthJson(String groundTruthJson) { this.groundTruthJson = groundTruthJson; }   // <-- NEW SETTER
}