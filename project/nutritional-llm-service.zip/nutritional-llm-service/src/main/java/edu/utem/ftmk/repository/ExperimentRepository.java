package edu.utem.ftmk.repository;

import edu.utem.ftmk.entity.Experiment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ExperimentRepository extends JpaRepository<Experiment, Integer> {
    
    List<Experiment> findByStatus(String status);
    
    List<Experiment> findByTranscriptId(Integer transcriptId);
    
    @Query("SELECT e FROM Experiment e WHERE e.modelId = :modelId AND e.techniqueId = :techniqueId")
    List<Experiment> findByModelAndTechnique(@Param("modelId") Integer modelId, 
                                              @Param("techniqueId") Integer techniqueId);
    
    @Query("SELECT COUNT(e) FROM Experiment e WHERE e.status = :status")
    long countByStatus(@Param("status") String status);
    
    @Query("SELECT e.status, COUNT(e) FROM Experiment e GROUP BY e.status")
    List<Object[]> countGroupByStatus();
}