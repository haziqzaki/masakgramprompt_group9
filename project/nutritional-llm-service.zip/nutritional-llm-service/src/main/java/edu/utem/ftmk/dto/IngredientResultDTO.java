package edu.utem.ftmk.dto;

public class IngredientResultDTO {
    private int ingredientId;
    private String nameOriginal;
    private String nameEn;
    private double quantity;
    private String unitOriginal;
    private String unitEn;
    private double estimatedWeight;
    private double calories;
    private double protein;
    private double fat;
    private double carbs;
    private boolean hallucinated;

    // Default Constructor
    public IngredientResultDTO() {}

    // Getters
    public int getIngredientId() { return ingredientId; }
    public String getNameOriginal() { return nameOriginal; }
    public String getNameEn() { return nameEn; }
    public double getQuantity() { return quantity; }
    public String getUnitOriginal() { return unitOriginal; }
    public String getUnitEn() { return unitEn; }
    public double getEstimatedWeight() { return estimatedWeight; }
    public double getCalories() { return calories; }
    public double getProtein() { return protein; }
    public double getFat() { return fat; }
    public double getCarbs() { return carbs; }
    public boolean isHallucinated() { return hallucinated; }

    // Setters
    public void setIngredientId(int ingredientId) { this.ingredientId = ingredientId; }
    public void setNameOriginal(String nameOriginal) { this.nameOriginal = nameOriginal; }
    public void setNameEn(String nameEn) { this.nameEn = nameEn; }
    public void setQuantity(double quantity) { this.quantity = quantity; }
    public void setUnitOriginal(String unitOriginal) { this.unitOriginal = unitOriginal; }
    public void setUnitEn(String unitEn) { this.unitEn = unitEn; }
    public void setEstimatedWeight(double estimatedWeight) { this.estimatedWeight = estimatedWeight; }
    public void setCalories(double calories) { this.calories = calories; }
    public void setProtein(double protein) { this.protein = protein; }
    public void setFat(double fat) { this.fat = fat; }
    public void setCarbs(double carbs) { this.carbs = carbs; }
    public void setHallucinated(boolean hallucinated) { this.hallucinated = hallucinated; }
}