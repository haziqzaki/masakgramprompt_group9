package edu.utem.ftmk.llm;

import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.ollama.OllamaChatModel;

import java.sql.*;
import java.time.Duration;
import java.util.*;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ExperimentRunner {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/nutritional_llm?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kuala_Lumpur";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    private static final String OLLAMA_BASE_URL = "http://localhost:11434";

    // Model tags matching your Ollama installation
    private static final String[] MODELS = {
        "llama3.2:3b",
        "phi4-mini",
        "qwen2.5:3b",
        "aisingapore/Gemma-SEA-LION-v4-4B-VL",
        "medgemma:4b"
    };

    // Prompt techniques
    private static final String[] TECHNIQUES = {
        "zero-shot",
        "few-shot",
        "chain-of-thought",
        "structured-output"
    };

    public static void main(String[] args) {
        ExperimentRunner runner = new ExperimentRunner();
        runner.runAllExperiments();
    }

    public void runAllExperiments() {
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║         🚀 Running ALL Experiments (200 total)             ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");

        List<Integer> transcriptIds = getTranscriptIds();

        if (transcriptIds.isEmpty()) {
            System.out.println("❌ No transcripts found!");
            return;
        }

        int total = 0;
        int success = 0;
        int failed = 0;

        System.out.println("\n📊 Found " + transcriptIds.size() + " videos.");
        System.out.println("📊 Models: " + MODELS.length + ", Techniques: " + TECHNIQUES.length);
        System.out.println("📊 Total experiments: " + transcriptIds.size() + " × " + MODELS.length + " × " + TECHNIQUES.length + " = " + (transcriptIds.size() * MODELS.length * TECHNIQUES.length));
        System.out.println("=====================================\n");

        for (int transcriptId : transcriptIds) {
            String transcript = getTranscriptContent(transcriptId);
            if (transcript == null || transcript.isEmpty()) {
                System.err.println("⚠️ Skipping transcript " + transcriptId + " - content empty");
                continue;
            }

            for (String modelTag : MODELS) {
                for (String technique : TECHNIQUES) {
                    total++;
                    try {
                        System.out.print("[" + total + "/200] Video: " + transcriptId +
                                       " | Model: " + modelTag +
                                       " | Technique: " + technique + " ... ");

                        String systemPrompt = getSystemPrompt(technique);
                        String userPrompt = getUserPrompt(technique, transcript);

                        String response = sendPrompt(modelTag, systemPrompt, userPrompt);

                        // Get model_id and technique_id from database
                        int modelId = getModelId(modelTag);
                        int techniqueId = getTechniqueId(technique);

                        if (modelId == -1 || techniqueId == -1) {
                            System.out.println("❌ FAILED: Model or technique not found in database");
                            failed++;
                            continue;
                        }

                        saveResult(transcriptId, modelId, techniqueId, response);

                        System.out.println("✅ SUCCESS");
                        success++;

                    } catch (Exception e) {
                        System.out.println("❌ FAILED: " + e.getMessage());
                        failed++;
                    }

                    try { Thread.sleep(2000); } catch (InterruptedException e) {}
                }
            }
        }

        System.out.println("\n=====================================");
        System.out.println("✅ EXPERIMENTS COMPLETE!");
        System.out.println("   Total  : " + total);
        System.out.println("   Success: " + success);
        System.out.println("   Failed : " + failed);
        System.out.println("=====================================");
    }

    // ──────────────────────────────────────────────────────────────
    // DATABASE METHODS
    // ──────────────────────────────────────────────────────────────

    private List<Integer> getTranscriptIds() {
        List<Integer> ids = new ArrayList<>();
        String sql = "SELECT transcript_id FROM transcript ORDER BY transcript_id";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                ids.add(rs.getInt("transcript_id"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ids;
    }

    private String getTranscriptContent(int transcriptId) {
        String sql = "SELECT content FROM transcript WHERE transcript_id = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transcriptId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("content");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private int getModelId(String modelTag) {
        String sql = "SELECT model_id FROM llm_model WHERE model_tag = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, modelTag);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("model_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int getTechniqueId(String techniqueName) {
        String sql = "SELECT technique_id FROM prompt_technique WHERE technique_name = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, techniqueName);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("technique_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int insertExperiment(int transcriptId, int modelId, int techniqueId) {
        String sql = "INSERT INTO experiment (transcript_id, model_id, technique_id, rag_enabled, status, executed_at) " +
                     "VALUES (?, ?, ?, FALSE, 'completed', NOW())";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, transcriptId);
            pstmt.setInt(2, modelId);
            pstmt.setInt(3, techniqueId);
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private int insertNutritionResult(int experimentId, String jsonResponse) {
        String sql = "INSERT INTO nutrition_result (experiment_id, raw_json_output, json_valid, created_at) " +
                     "VALUES (?, ?, TRUE, NOW())";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, experimentId);
            pstmt.setString(2, jsonResponse);
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    private void saveResult(int transcriptId, int modelId, int techniqueId, String response) {
        int experimentId = insertExperiment(transcriptId, modelId, techniqueId);
        if (experimentId > 0) {
            int nutritionResultId = insertNutritionResult(experimentId, response);
            if (nutritionResultId > 0) {
                parseAndInsertIngredients(nutritionResultId, response);
            }
        }
    }

    private void parseAndInsertIngredients(int nutritionResultId, String jsonResponse) {
        try {
            // Clean the JSON first
            String cleanedJson = cleanJsonResponse(jsonResponse);
            if (cleanedJson == null) {
                System.err.println("   ⚠️ No valid JSON found");
                return;
            }

            JsonObject root = JsonParser.parseString(cleanedJson).getAsJsonObject();
            
            JsonArray ingredients = root.getAsJsonArray("ingredients");
            if (ingredients == null || ingredients.size() == 0) {
                System.err.println("   ⚠️ No ingredients found");
                return;
            }
            
            String sql = "INSERT INTO ingredient_result (" +
                "result_id, name_original, name_en, quantity_value, " +
                "unit_original, unit_en, estimated_weight_g, " +
                "calories, total_fat_g, saturated_fat_g, cholesterol_mg, " +
                "sodium_mg, total_carbohydrate_g, dietary_fiber_g, " +
                "total_sugars_g, protein_g, vitamin_d_mcg, calcium_mg, iron_mg, potassium_mg" +
                ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                
                for (com.google.gson.JsonElement element : ingredients) {
                    JsonObject ing = element.getAsJsonObject();
                    
                    pstmt.setInt(1, nutritionResultId);
                    pstmt.setString(2, getString(ing, "ingredient_name_original"));
                    pstmt.setString(3, getString(ing, "ingredient_name_en"));
                    pstmt.setDouble(4, getDouble(ing, "quantity_value"));
                    pstmt.setString(5, getString(ing, "quantity_unit_original"));
                    pstmt.setString(6, getString(ing, "quantity_unit_en"));
                    pstmt.setDouble(7, getDouble(ing, "estimated_weight_g"));
                    pstmt.setDouble(8, getDouble(ing, "calories"));
                    pstmt.setDouble(9, getDouble(ing, "total_fat_g"));
                    pstmt.setDouble(10, getDouble(ing, "saturated_fat_g"));
                    pstmt.setDouble(11, getDouble(ing, "cholesterol_mg"));
                    pstmt.setDouble(12, getDouble(ing, "sodium_mg"));
                    pstmt.setDouble(13, getDouble(ing, "total_carbohydrate_g"));
                    pstmt.setDouble(14, getDouble(ing, "dietary_fiber_g"));
                    pstmt.setDouble(15, getDouble(ing, "total_sugars_g"));
                    pstmt.setDouble(16, getDouble(ing, "protein_g"));
                    pstmt.setDouble(17, getDouble(ing, "vitamin_d_mcg"));
                    pstmt.setDouble(18, getDouble(ing, "calcium_mg"));
                    pstmt.setDouble(19, getDouble(ing, "iron_mg"));
                    pstmt.setDouble(20, getDouble(ing, "potassium_mg"));
                    pstmt.addBatch();
                }
                pstmt.executeBatch();
                System.out.println("   ✅ Parsed " + ingredients.size() + " ingredients");
            }
        } catch (Exception e) {
            System.err.println("   ⚠️ Failed to parse ingredients: " + e.getMessage());
        }
    }

    /**
     * Cleans the raw JSON response by removing markdown, prose, and extracting only the JSON portion.
     */
    private String cleanJsonResponse(String raw) {
        if (raw == null || raw.isEmpty()) return null;
        
        // Remove markdown code blocks (```json ... ```)
        String cleaned = raw.replaceAll("(?s)```json\\s*", "");
        cleaned = cleaned.replaceAll("(?s)```\\s*", "");
        
        // Find the first { and last }
        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        
        if (start >= 0 && end > start) {
            return cleaned.substring(start, end + 1).trim();
        }
        
        return null;
    }

    private String getString(JsonObject obj, String key) {
        return obj.has(key) && !obj.get(key).isJsonNull() ? obj.get(key).getAsString() : null;
    }

    private double getDouble(JsonObject obj, String key) {
        if (obj.has(key) && !obj.get(key).isJsonNull()) {
            try {
                return obj.get(key).getAsDouble();
            } catch (Exception e) {
                // Try to parse as string
                try {
                    String val = obj.get(key).getAsString();
                    val = val.replaceAll("[^0-9.]", "");
                    if (!val.isEmpty()) {
                        return Double.parseDouble(val);
                    }
                } catch (Exception e2) {
                    return 0.0;
                }
            }
        }
        return 0.0;
    }

    // ──────────────────────────────────────────────────────────────
    // PROMPT METHODS (UPDATED FOR STRICT JSON)
    // ──────────────────────────────────────────────────────────────

    private String getSystemPrompt(String technique) {
        String baseInstruction =
            "You are a nutritional analyst specializing in Malaysian cuisine.\n" +
            "Extract all ingredients and quantities from the transcript.\n\n" +
            "⚠️ CRITICAL INSTRUCTION: You MUST return ONLY valid JSON.\n" +
            "⚠️ DO NOT include any explanation, prose, markdown, or text outside the JSON.\n" +
            "⚠️ DO NOT wrap the JSON in ```json ... ``` code blocks.\n" +
            "⚠️ Start your response with { and end with }.\n" +
            "⚠️ If you include any text outside the JSON, the response will be rejected.\n\n" +
            "Return valid JSON only.";

        switch (technique) {
            case "zero-shot":
                return baseInstruction;
            case "few-shot":
                return baseInstruction + "\n\nFollow the example format exactly. Return valid JSON only.";
            case "chain-of-thought":
                return baseInstruction + "\n\nThink step by step internally, but ONLY output the final JSON. Do not include your reasoning.";
            case "structured-output":
                return baseInstruction + "\n\nUse the exact schema provided. Return valid JSON only.";
            default:
                return baseInstruction;
        }
    }

    private String getUserPrompt(String technique, String transcript) {
        String baseInstruction =
            "Analyze this transcript and produce a nutrition facts sheet in JSON.\n\n" +
            "⚠️ CRITICAL: Return ONLY valid JSON. NO markdown, NO explanation, NO prose.\n" +
            "⚠️ Start with { and end with }.\n\n" +
            "Transcript:\n\"\"\"" + transcript + "\n\"\"\"\n\n" +
            "Return ONLY valid JSON. Do not include any other text.";

        switch (technique) {
            case "zero-shot":
                return baseInstruction +
                    "\n\n{\n" +
                    "  \"recipe_name\": \"\",\n" +
                    "  \"servings_estimated\": 0,\n" +
                    "  \"ingredients\": [],\n" +
                    "  \"nutrition_total\": {}\n" +
                    "}";
            case "few-shot":
                return baseInstruction +
                    "\n\nExample format:\n" +
                    "{\n" +
                    "  \"recipe_name\": \"Telur Goreng\",\n" +
                    "  \"servings_estimated\": 1,\n" +
                    "  \"ingredients\": [\n" +
                    "    {\n" +
                    "      \"ingredient_name_original\": \"minyak\",\n" +
                    "      \"ingredient_name_en\": \"cooking oil\",\n" +
                    "      \"quantity_value\": 2,\n" +
                    "      \"quantity_unit_original\": \"sudu besar\",\n" +
                    "      \"quantity_unit_en\": \"tablespoon\",\n" +
                    "      \"estimated_weight_g\": 28,\n" +
                    "      \"calories\": 248,\n" +
                    "      \"total_fat_g\": 28,\n" +
                    "      \"protein_g\": 0,\n" +
                    "      \"total_carbohydrate_g\": 0\n" +
                    "    }\n" +
                    "  ],\n" +
                    "  \"nutrition_total\": {\n" +
                    "    \"calories\": 248,\n" +
                    "    \"total_fat_g\": 28,\n" +
                    "    \"protein_g\": 0,\n" +
                    "    \"total_carbohydrate_g\": 0\n" +
                    "  }\n" +
                    "}\n\n" +
                    "Now analyze this transcript. Return ONLY valid JSON.";
            case "chain-of-thought":
                return "Analyze this transcript and return ONLY valid JSON.\n\n" +
                    "Transcript:\n\"\"\"" + transcript + "\n\"\"\"\n\n" +
                    "Return ONLY valid JSON. No reasoning, no explanation, no markdown.";
            case "structured-output":
                return "Extract ingredients and nutrition from this transcript.\n\n" +
                    "⚠️ Return ONLY valid JSON matching this schema.\n" +
                    "⚠️ NO markdown, NO explanation, NO prose.\n\n" +
                    "Transcript:\n\"\"\"" + transcript + "\n\"\"\"\n\n" +
                    "Return ONLY valid JSON. Start with { and end with }.";
            default:
                return "Return ONLY valid JSON for this transcript:\n\"\"\"" + transcript + "\n\"\"\"";
        }
    }

    private String sendPrompt(String modelTag, String systemPrompt, String userPrompt) {
        ChatModel chatModel = OllamaChatModel.builder()
                .baseUrl(OLLAMA_BASE_URL)
                .modelName(modelTag)
                .timeout(Duration.ofMinutes(5))
                .build();

        String fullPrompt = systemPrompt + "\n\n" + userPrompt;
        return chatModel.chat(fullPrompt);
    }
}