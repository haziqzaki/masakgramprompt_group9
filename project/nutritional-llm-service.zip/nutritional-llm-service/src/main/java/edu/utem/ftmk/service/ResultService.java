package edu.utem.ftmk.service;

import edu.utem.ftmk.dto.ExperimentResultDTO;
import edu.utem.ftmk.dto.IngredientResultDTO;
import edu.utem.ftmk.entity.GroundTruthIngredient;
import edu.utem.ftmk.repository.GroundTruthIngredientRepository;
import com.google.gson.Gson;                               // <-- NEW IMPORT
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ResultService {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/masakgramprompt?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kuala_Lumpur";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    @Autowired
    private GroundTruthIngredientRepository groundTruthIngredientRepository;

    public List<ExperimentResultDTO> getFilteredResults(String modelFilter, String techniqueFilter) {
        List<ExperimentResultDTO> results = new ArrayList<>();
        
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT DISTINCT ");
        sql.append("e.experiment_id, e.transcript_id, e.status, e.executed_at, ");
        sql.append("m.model_name, p.technique_name, ");
        sql.append("nr.recipe_name, nr.servings_estimated, ");
        sql.append("nr.total_calories, nr.total_protein_g, nr.total_fat_g, nr.total_carbohydrate_g, ");
        sql.append("nr.raw_json_output, ");                     // ← fixed extra comma
        sql.append("t.content AS transcript_content ");        // ← added missing column
        sql.append("FROM experiment e ");
        sql.append("JOIN llm_model m ON e.model_id = m.model_id ");
        sql.append("JOIN prompt_technique p ON e.technique_id = p.technique_id ");
        sql.append("LEFT JOIN nutrition_result nr ON e.experiment_id = nr.experiment_id ");
        sql.append("LEFT JOIN transcript t ON e.transcript_id = t.transcript_id ");
        sql.append("WHERE e.status = 'completed' ");
        
        List<String> conditions = new ArrayList<>();
        if (modelFilter != null && !modelFilter.isEmpty() && !modelFilter.equals("undefined") && !modelFilter.equals("null")) {
            conditions.add("m.model_name = '" + modelFilter + "'");
        }
        if (techniqueFilter != null && !techniqueFilter.isEmpty() && !techniqueFilter.equals("undefined") && !techniqueFilter.equals("null")) {
            conditions.add("p.technique_name = '" + techniqueFilter + "'");
        }
        if (!conditions.isEmpty()) {
            sql.append("AND ").append(String.join(" AND ", conditions));
        }
        sql.append(" ORDER BY e.experiment_id DESC");
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql.toString())) {
            
            while (rs.next()) {
                ExperimentResultDTO dto = new ExperimentResultDTO();
                dto.setExperimentId(rs.getInt("experiment_id"));
                dto.setTranscriptId(rs.getInt("transcript_id"));
                dto.setModelName(rs.getString("model_name"));
                dto.setTechniqueName(rs.getString("technique_name"));
                dto.setStatus(rs.getString("status"));
                dto.setExecutedAt(rs.getTimestamp("executed_at"));
                
                // Get recipe name - try database first, then extract from JSON
                String recipeName = rs.getString("recipe_name");
                System.out.println("🔍 Recipe Name from DB: " + recipeName);
                String rawJson = rs.getString("raw_json_output");
                
                if ((recipeName == null || recipeName.isEmpty()) && rawJson != null && !rawJson.isEmpty()) {
                    String extractedName = extractRecipeNameFromJson(rawJson);
                    if (extractedName != null && !extractedName.isEmpty()) {
                        recipeName = extractedName;
                    }
                }
                
                if (recipeName == null || recipeName.isEmpty()) {
                    recipeName = "Unknown Recipe";
                }
                
                dto.setRecipeName(recipeName);
                dto.setServingsEstimated(rs.getInt("servings_estimated"));
                dto.setTotalCalories(rs.getDouble("total_calories"));
                dto.setTotalProtein(rs.getDouble("total_protein_g"));
                dto.setTotalFat(rs.getDouble("total_fat_g"));
                dto.setTotalCarbs(rs.getDouble("total_carbohydrate_g"));
                dto.setRawJson(rawJson);
                
                String content = rs.getString("transcript_content");
                if (content != null && !content.isEmpty()) {
                    if (content.length() > 150) {
                        dto.setTranscriptPreview(content.substring(0, 150) + "...");
                    } else {
                        dto.setTranscriptPreview(content);
                    }
                } else {
                    dto.setTranscriptPreview("No transcript content available");
                }
                
                // Get ingredients for this result
                dto.setIngredients(getIngredientsForResult(rs.getInt("experiment_id")));
                
                // ============================================================
                // GROUND TRUTH INGREDIENTS
                // ============================================================
                List<String> groundTruth = groundTruthIngredientRepository
                        .findByTranscriptId(rs.getInt("transcript_id"))
                        .stream()
                        .map(GroundTruthIngredient::getIngredientName)
                        .collect(Collectors.toList());
                dto.setGroundTruthIngredients(groundTruth);
                System.out.println("Transcript ID: " + rs.getInt("transcript_id") + 
                        " | Ground truth count: " + groundTruth.size());
                
                // NEW: Convert to JSON string and set in DTO
                Gson gson = new Gson();
                dto.setGroundTruthJson(gson.toJson(groundTruth));
                // ============================================================
                
                // Count ingredients and hallucinated
                int totalIng = 0;
                int halluCount = 0;
                for (IngredientResultDTO ing : dto.getIngredients()) {
                    totalIng++;
                    if (ing.isHallucinated()) halluCount++;
                }
                dto.setIngredientCount(totalIng);
                dto.setHallucinatedCount(halluCount);
                
                results.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return results;
    }

    private String extractRecipeNameFromJson(String json) {
        try {
            String cleanJson = json.trim();
            
            if (cleanJson.startsWith("```json")) {
                cleanJson = cleanJson.substring(7);
            }
            if (cleanJson.startsWith("```")) {
                cleanJson = cleanJson.substring(3);
            }
            if (cleanJson.endsWith("```")) {
                cleanJson = cleanJson.substring(0, cleanJson.length() - 3);
            }
            cleanJson = cleanJson.trim();
            
            JsonObject obj = JsonParser.parseString(cleanJson).getAsJsonObject();
            
            if (obj.has("recipe_name") && !obj.get("recipe_name").isJsonNull()) {
                return obj.get("recipe_name").getAsString();
            }
            if (obj.has("name") && !obj.get("name").isJsonNull()) {
                return obj.get("name").getAsString();
            }
            if (obj.has("title") && !obj.get("title").isJsonNull()) {
                return obj.get("title").getAsString();
            }
            if (obj.has("recipe") && obj.get("recipe").isJsonObject()) {
                JsonObject recipe = obj.get("recipe").getAsJsonObject();
                if (recipe.has("name") && !recipe.get("name").isJsonNull()) {
                    return recipe.get("name").getAsString();
                }
            }
        } catch (Exception e) {
            try {
                int startIndex = json.indexOf("\"recipe_name\"");
                if (startIndex != -1) {
                    int colonIndex = json.indexOf(":", startIndex);
                    if (colonIndex != -1) {
                        int quoteStart = json.indexOf("\"", colonIndex + 1);
                        if (quoteStart != -1) {
                            int quoteEnd = json.indexOf("\"", quoteStart + 1);
                            if (quoteEnd != -1) {
                                return json.substring(quoteStart + 1, quoteEnd);
                            }
                        }
                    }
                }
            } catch (Exception e2) {
                // Ignore
            }
        }
        return null;
    }

    public List<IngredientResultDTO> getIngredientsForResult(int experimentId) {
        List<IngredientResultDTO> ingredients = new ArrayList<>();
        String sql = "SELECT ir.ingredient_id, ir.name_original, ir.name_en, " +
                     "ir.quantity_value, ir.unit_original, ir.unit_en, " +
                     "ir.estimated_weight_g, ir.calories, ir.protein_g, " +
                     "ir.total_fat_g, ir.total_carbohydrate_g, ir.is_hallucinated " +
                     "FROM ingredient_result ir " +
                     "JOIN nutrition_result nr ON ir.result_id = nr.result_id " +
                     "JOIN experiment e ON nr.experiment_id = e.experiment_id " +
                     "WHERE e.experiment_id = ?";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, experimentId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                IngredientResultDTO dto = new IngredientResultDTO();
                dto.setIngredientId(rs.getInt("ingredient_id"));
                dto.setNameOriginal(rs.getString("name_original"));
                dto.setNameEn(rs.getString("name_en"));
                dto.setQuantity(rs.getDouble("quantity_value"));
                dto.setUnitOriginal(rs.getString("unit_original"));
                dto.setUnitEn(rs.getString("unit_en"));
                dto.setEstimatedWeight(rs.getDouble("estimated_weight_g"));
                dto.setCalories(rs.getDouble("calories"));
                dto.setProtein(rs.getDouble("protein_g"));
                dto.setFat(rs.getDouble("total_fat_g"));
                dto.setCarbs(rs.getDouble("total_carbohydrate_g"));
                dto.setHallucinated(rs.getBoolean("is_hallucinated"));
                ingredients.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ingredients;
    }

    public Map<String, List<String>> getFilterOptions() {
        Map<String, List<String>> options = new HashMap<>();
        List<String> models = new ArrayList<>();
        List<String> techniques = new ArrayList<>();
        
        String sqlModels = "SELECT DISTINCT model_name FROM llm_model ORDER BY model_name";
        String sqlTechniques = "SELECT DISTINCT technique_name FROM prompt_technique ORDER BY technique_name";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {
            
            ResultSet rs = stmt.executeQuery(sqlModels);
            while (rs.next()) {
                models.add(rs.getString("model_name"));
            }
            
            rs = stmt.executeQuery(sqlTechniques);
            while (rs.next()) {
                techniques.add(rs.getString("technique_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        options.put("models", models);
        options.put("techniques", techniques);
        return options;
    }

    public int getTotalIngredients(List<ExperimentResultDTO> results) {
        int total = 0;
        if (results != null) {
            for (ExperimentResultDTO r : results) {
                total += r.getIngredientCount();
            }
        }
        return total;
    }
}