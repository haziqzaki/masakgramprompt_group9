package edu.utem.ftmk.runner;

import java.sql.*;
import java.nio.file.*;
import java.io.*;

public class PopulateTranscriptContent {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/masakgramprompt?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kuala_Lumpur";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════════╗");
        System.out.println("║     📝 Populating Transcript Content from Files           ║");
        System.out.println("╚════════════════════════════════════════════════════════════╝");
        System.out.println();
        
        populateContentFromFiles();
    }

    private static void populateContentFromFiles() {
        String sql = "SELECT transcript_id, file_path FROM transcript WHERE content IS NULL OR content = ''";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            int updated = 0;
            int notFound = 0;
            int total = 0;
            
            while (rs.next()) {
                total++;
                int id = rs.getInt("transcript_id");
                String filePath = rs.getString("file_path");
                
                if (filePath == null || filePath.isEmpty()) {
                    System.out.println("⚠️ No file_path for transcript ID: " + id);
                    continue;
                }
                
                try {
                    // Fix Windows path
                    String fixedPath = filePath.replace("\\", "/");
                    Path path = Paths.get(fixedPath);
                    
                    if (Files.exists(path)) {
                        String content = new String(Files.readAllBytes(path), 
                                                   java.nio.charset.StandardCharsets.UTF_8);
                        
                        String updateSql = "UPDATE transcript SET content = ? WHERE transcript_id = ?";
                        try (PreparedStatement pstmt = conn.prepareStatement(updateSql)) {
                            pstmt.setString(1, content);
                            pstmt.setInt(2, id);
                            pstmt.executeUpdate();
                            updated++;
                            System.out.println("✅ [" + total + "] Transcript " + id + " updated");
                        }
                    } else {
                        notFound++;
                        System.out.println("⚠️ [" + total + "] File not found: " + fixedPath);
                    }
                } catch (Exception e) {
                    System.err.println("❌ [" + total + "] Error for ID " + id + ": " + e.getMessage());
                }
            }
            
            System.out.println("\n=====================================");
            System.out.println("✅ POPULATION COMPLETE!");
            System.out.println("   Total processed: " + total);
            System.out.println("   Updated: " + updated + " transcripts");
            System.out.println("   Not found: " + notFound + " files");
            
            // Verify
            String verifySql = "SELECT COUNT(*) FROM transcript WHERE content IS NOT NULL AND content != ''";
            try (Statement vStmt = conn.createStatement();
                 ResultSet vRs = vStmt.executeQuery(verifySql)) {
                if (vRs.next()) {
                    System.out.println("   Total transcripts with content: " + vRs.getInt(1));
                }
            }
            System.out.println("=====================================");
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}