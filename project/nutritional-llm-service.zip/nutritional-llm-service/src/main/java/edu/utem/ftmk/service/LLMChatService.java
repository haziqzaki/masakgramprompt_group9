package edu.utem.ftmk.service;

import dev.langchain4j.model.chat.ChatModel;
import dev.langchain4j.model.ollama.OllamaChatModel;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.*;

@Service
public class LLMChatService {

    private static final String OLLAMA_BASE_URL = "http://localhost:11434";

    // Available models
    private static final Map<String, String> MODELS = new LinkedHashMap<>();
    static {
        MODELS.put("llama3.2:3b", "Llama 3.2 3B");
        MODELS.put("phi4-mini", "Phi-4-mini 3.8B");
        MODELS.put("qwen2.5:3b", "Qwen 2.5 3B");
        MODELS.put("aisingapore/Gemma-SEA-LION-v4-4B-VL", "Gemma-SEA-LION v4 4B");
        MODELS.put("medgemma:4b", "MedGemma 4B");
    }

    // Available prompt techniques
    private static final Map<String, String> TECHNIQUES = new LinkedHashMap<>();
    static {
        TECHNIQUES.put("zero-shot", "Zero-Shot");
        TECHNIQUES.put("few-shot", "Few-Shot");
        TECHNIQUES.put("chain-of-thought", "Chain-of-Thought");
        TECHNIQUES.put("structured-output", "Structured Output");
    }

    // Max prompt length for speed
    private static final int MAX_PROMPT_LENGTH = 800;

    public Map<String, String> getModels() {
        return MODELS;
    }

    public Map<String, String> getTechniques() {
        return TECHNIQUES;
    }

    // ============================================================
    // SEND CHAT
    // ============================================================
    public String sendChat(String modelTag, String prompt, String technique) {
        try {
            // Truncate prompt for speed
            String truncatedPrompt = prompt;
            if (prompt.length() > MAX_PROMPT_LENGTH) {
                truncatedPrompt = prompt.substring(0, MAX_PROMPT_LENGTH) + "...";
                System.out.println("⚡ Prompt truncated from " + prompt.length() + " to " + MAX_PROMPT_LENGTH + " chars");
            }

            String systemPrompt = getSystemPrompt(technique);
            String fullPrompt = systemPrompt + "\n\n" + truncatedPrompt;

            System.out.println("📤 Sending to: " + modelTag + " | Technique: " + technique);

            // 🔥 INCREASE TIMEOUT TO 5 MINUTES
            ChatModel chatModel = OllamaChatModel.builder()
                    .baseUrl(OLLAMA_BASE_URL)
                    .modelName(modelTag)
                    .timeout(Duration.ofMinutes(5))  // ← Increased from 60 seconds
                    .build();

            long startTime = System.currentTimeMillis();
            String response = chatModel.chat(fullPrompt);
            long endTime = System.currentTimeMillis();

            System.out.println("✅ Response received in " + (endTime - startTime) / 1000 + " seconds");
            return response;

        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            return "❌ Error: " + e.getMessage();
        }
    }
    // ============================================================
    // SYSTEM PROMPT - STRICT JSON WITH NUTRITION
    // ============================================================
    private String getSystemPrompt(String technique) {
        String baseInstruction =
            "⚠️ IMPORTANT RULES FOR NUTRITION ESTIMATION:\n" +
            "1. Calories should be between 0-900 per 100g for most foods\n" +
            "2. Salt (garam) = 0 calories, 0 protein, 0 fat, 0 carbs\n" +
            "3. Sugar (gula) = 387 calories per 100g, 0 protein, 0 fat, 100g carbs\n" +
            "4. Cooking oil (minyak) = 884 calories per 100g, 0 protein, 100g fat\n" +
            "5. For liquids like tamarind water (air asam jawa): ~20 calories per 100ml\n" +
            "6. DO NOT include cooking equipment as ingredients (api, oven, periuk, etc.)\n" +
            "7. All ingredients must have estimated_weight_g > 0\n\n" +
            "Use these per-100g values:\n" +
            "- Onion: 40 cal, 1.1g protein, 0.1g fat, 9g carbs\n" +
            "- Garlic: 149 cal, 6.4g protein, 0.5g fat, 33g carbs\n" +
            "- Chili: 40 cal, 2g protein, 0.4g fat, 9g carbs\n" +
            "- Tomato: 18 cal, 0.9g protein, 0.2g fat, 4g carbs\n" +
            "- Tamarind water: 20 cal, 0.5g protein, 0g fat, 5g carbs per 100ml\n" +
            "- Salt: 0 cal, 0g protein, 0g fat, 0g carbs\n" +
            "- Sugar: 387 cal, 0g protein, 0g fat, 100g carbs\n" +
            "- Fish (mackerel): 205 cal, 19g protein, 14g fat, 0g carbs\n\n" +
            "Calculate nutrition based on estimated_weight_g.\n" +
            "Return valid JSON only.";

        switch (technique) {
            case "zero-shot":
                return baseInstruction;
            case "few-shot":
                return baseInstruction +
                    "\n\nExample output:\n" +
                    "{\"recipe_name\":\"Telur Goreng\",\"servings_estimated\":1," +
                    "\"ingredients\":[{\"ingredient_name_original\":\"telur\",\"ingredient_name_en\":\"egg\"," +
                    "\"quantity_value\":2,\"quantity_unit_original\":\"biji\",\"quantity_unit_en\":\"piece\"," +
                    "\"estimated_weight_g\":100,\"calories\":155,\"protein_g\":13,\"total_carbohydrate_g\":1,\"total_fat_g\":11}]," +
                    "\"nutrition_total\":{\"calories\":155,\"protein_g\":13,\"total_carbohydrate_g\":1,\"total_fat_g\":11}}";
            case "chain-of-thought":
                return baseInstruction +
                    "\n\nThink step by step:\n" +
                    "1. Identify all ingredients\n" +
                    "2. Extract quantities and units\n" +
                    "3. Convert to grams\n" +
                    "4. Estimate nutrition per ingredient\n" +
                    "5. Sum totals\n" +
                    "6. Return valid JSON";
            case "structured-output":
                return baseInstruction;
            default:
                return baseInstruction;
        }
    }

    public String getModelDisplayName(String modelTag) {
        return MODELS.getOrDefault(modelTag, modelTag);
    }

    public String getTechniqueDisplayName(String technique) {
        return TECHNIQUES.getOrDefault(technique, technique);
    }
}