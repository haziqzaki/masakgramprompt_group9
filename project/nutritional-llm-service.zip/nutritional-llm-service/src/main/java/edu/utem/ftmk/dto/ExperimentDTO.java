package edu.utem.ftmk.dto;

import java.sql.Timestamp;

public class ExperimentDTO {
    private int experimentId;
    private int transcriptId;
    private String modelName;
    private String techniqueName;
    private String status;
    private Timestamp executedAt;
    private boolean ragEnabled;

    public ExperimentDTO() {}

    public int getExperimentId() { return experimentId; }
    public void setExperimentId(int experimentId) { this.experimentId = experimentId; }
    
    public int getTranscriptId() { return transcriptId; }
    public void setTranscriptId(int transcriptId) { this.transcriptId = transcriptId; }
    
    public String getModelName() { return modelName; }
    public void setModelName(String modelName) { this.modelName = modelName; }
    
    public String getTechniqueName() { return techniqueName; }
    public void setTechniqueName(String techniqueName) { this.techniqueName = techniqueName; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Timestamp getExecutedAt() { return executedAt; }
    public void setExecutedAt(Timestamp executedAt) { this.executedAt = executedAt; }
    
    public boolean isRagEnabled() { return ragEnabled; }
    public void setRagEnabled(boolean ragEnabled) { this.ragEnabled = ragEnabled; }
}