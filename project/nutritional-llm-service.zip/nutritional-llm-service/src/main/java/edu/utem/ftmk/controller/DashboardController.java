package edu.utem.ftmk.controller;

import edu.utem.ftmk.dto.ExperimentDTO;
import edu.utem.ftmk.dto.ModelPerformanceDTO;
import edu.utem.ftmk.dto.StatisticsDTO;
import edu.utem.ftmk.dto.LayerMetricsDTO;
import edu.utem.ftmk.service.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        // Statistics
        StatisticsDTO stats = dashboardService.getStatistics();
        model.addAttribute("stats", stats);
        
        // Layer 3 Metrics (from database directly)
        LayerMetricsDTO layer3 = dashboardService.getLayer3Metrics();
        model.addAttribute("layer3", layer3);
        
        // Recent experiments
        List<ExperimentDTO> experiments = dashboardService.getRecentExperiments();
        model.addAttribute("experiments", experiments);
        
        // Model performance
        List<ModelPerformanceDTO> performance = dashboardService.getModelPerformance();
        model.addAttribute("performance", performance);
        
        return "dashboard";
    }
}