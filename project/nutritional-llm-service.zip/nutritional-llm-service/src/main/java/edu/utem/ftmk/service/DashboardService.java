package edu.utem.ftmk.service;

import edu.utem.ftmk.dto.ExperimentDTO;
import edu.utem.ftmk.dto.ModelPerformanceDTO;
import edu.utem.ftmk.dto.StatisticsDTO;
import edu.utem.ftmk.dto.LayerMetricsDTO;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.*;

@Service
public class DashboardService {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/masakgramprompt?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kuala_Lumpur";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    // ============================================================
    // STATISTICS
    // ============================================================

    public StatisticsDTO getStatistics() {
        StatisticsDTO stats = new StatisticsDTO();
        
        String sql = "SELECT " +
            "(SELECT COUNT(*) FROM experiment) AS total_experiments, " +
            "(SELECT COUNT(*) FROM experiment WHERE status = 'completed') AS completed_experiments, " +
            "(SELECT COUNT(*) FROM experiment WHERE status = 'pending') AS pending_experiments, " +
            "(SELECT COUNT(*) FROM experiment WHERE status = 'failed') AS failed_experiments, " +
            "(SELECT COUNT(*) FROM nutrition_result) AS total_nutrition_results, " +
            "(SELECT COUNT(*) FROM ingredient_result) AS total_ingredients";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                stats.setTotalExperiments(rs.getInt("total_experiments"));
                stats.setCompletedExperiments(rs.getInt("completed_experiments"));
                stats.setPendingExperiments(rs.getInt("pending_experiments"));
                stats.setFailedExperiments(rs.getInt("failed_experiments"));
                stats.setTotalNutritionResults(rs.getInt("total_nutrition_results"));
                stats.setTotalIngredients(rs.getInt("total_ingredients"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stats;
    }

    // ============================================================
    // LAYER 3 METRICS - Reads directly from ingredient_result
    // NO layer3_metrics table needed!
    // ============================================================

    public LayerMetricsDTO getLayer3Metrics() {
        LayerMetricsDTO metrics = new LayerMetricsDTO();
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {
            
            // 1. JSON Validity Rate from nutrition_result
            String sql1 = "SELECT " +
                "COUNT(*) AS total, " +
                "SUM(CASE WHEN json_valid = 1 THEN 1 ELSE 0 END) AS valid_json " +
                "FROM nutrition_result";
            
            ResultSet rs = stmt.executeQuery(sql1);
            if (rs.next()) {
                int total = rs.getInt("total");
                int valid = rs.getInt("valid_json");
                metrics.setJsonValidityRate(total > 0 ? Math.round((valid * 100.0 / total) * 10) / 10.0 : 0);
            }
            
            // 2. Hallucination Rate from ingredient_result
            String sql2 = "SELECT " +
                "COUNT(*) AS total, " +
                "SUM(CASE WHEN is_hallucinated = 1 THEN 1 ELSE 0 END) AS hallucinated " +
                "FROM ingredient_result";
            
            rs = stmt.executeQuery(sql2);
            if (rs.next()) {
                int total = rs.getInt("total");
                int hallucinated = rs.getInt("hallucinated");
                metrics.setHallucinationRate(total > 0 ? Math.round((hallucinated * 100.0 / total) * 10) / 10.0 : 0);
            }
            
            // 3. Precision, Recall, F1 from ingredient_result
            // Precision = TP / (TP + FP)
            // Recall = TP / (TP + FN)
            // F1 = 2 * (Precision * Recall) / (Precision + Recall)
            String sql3 = "SELECT " +
                "SUM(CASE WHEN is_hallucinated = 0 THEN 1 ELSE 0 END) AS tp, " +
                "SUM(CASE WHEN is_hallucinated = 1 THEN 1 ELSE 0 END) AS fp, " +
                "COUNT(*) AS total " +
                "FROM ingredient_result";
            
            rs = stmt.executeQuery(sql3);
            if (rs.next()) {
                double tp = rs.getDouble("tp");
                double fp = rs.getDouble("fp");
                double total = rs.getDouble("total");
                
                // FN = total ground truth - TP (approximation)
                double fn = total - tp;
                
                double precision = (tp + fp) > 0 ? tp / (tp + fp) : 0;
                double recall = (tp + fn) > 0 ? tp / (tp + fn) : 0;
                double f1 = (precision + recall) > 0 ? 2 * (precision * recall) / (precision + recall) : 0;
                
                // Convert to percentage and round to 1 decimal
                metrics.setIngredientPrecision(Math.round(precision * 1000) / 10.0);
                metrics.setIngredientRecall(Math.round(recall * 1000) / 10.0);
                metrics.setIngredientF1(Math.round(f1 * 1000) / 10.0);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return metrics;
    }

    // ============================================================
    // LAYER 1 METRICS - From layer1_metrics table (if exists)
    // ============================================================

    public LayerMetricsDTO getLayer1Metrics() {
        LayerMetricsDTO metrics = new LayerMetricsDTO();
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {
            
            // Check if table exists
            String checkTable = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'nutritional_llm' AND table_name = 'layer1_metrics'";
            ResultSet rs = stmt.executeQuery(checkTable);
            rs.next();
            if (rs.getInt(1) == 0) {
                return metrics; // Table doesn't exist, return empty
            }
            
            String sql = "SELECT " +
                "ROUND(AVG(exact_match_name), 1) AS avg_exact_name, " +
                "ROUND(AVG(fuzzy_score), 1) AS avg_fuzzy, " +
                "ROUND(AVG(bleu_1), 1) AS avg_bleu1, " +
                "ROUND(AVG(bleu_2), 1) AS avg_bleu2, " +
                "ROUND(AVG(rouge_1), 1) AS avg_rouge1, " +
                "ROUND(AVG(rouge_l), 1) AS avg_rougeL " +
                "FROM layer1_metrics";
            
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                // Set values in metrics DTO
                // Note: You may need to add these fields to LayerMetricsDTO
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return metrics;
    }

    // ============================================================
    // LAYER 2 METRICS - From layer2_metrics table (if exists)
    // ============================================================

    public LayerMetricsDTO getLayer2Metrics() {
        LayerMetricsDTO metrics = new LayerMetricsDTO();
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {
            
            // Check if table exists
            String checkTable = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'nutritional_llm' AND table_name = 'layer2_metrics'";
            ResultSet rs = stmt.executeQuery(checkTable);
            rs.next();
            if (rs.getInt(1) == 0) {
                return metrics; // Table doesn't exist, return empty
            }
            
            String sql = "SELECT " +
                "ROUND(AVG(mae_quantity), 2) AS avg_mae_qty, " +
                "ROUND(AVG(mape_quantity), 1) AS avg_mape_qty, " +
                "ROUND(AVG(mae_weight), 2) AS avg_mae_weight, " +
                "ROUND(AVG(mape_weight), 1) AS avg_mape_weight, " +
                "ROUND(AVG(mae_energy), 2) AS avg_mae_energy, " +
                "ROUND(AVG(mape_energy), 1) AS avg_mape_energy, " +
                "ROUND(AVG(pearson_energy), 2) AS avg_pearson_energy " +
                "FROM layer2_metrics";
            
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                // Set values in metrics DTO
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return metrics;
    }

    // ============================================================
    // MODEL PERFORMANCE
    // ============================================================

    public List<ModelPerformanceDTO> getModelPerformance() {
        List<ModelPerformanceDTO> performance = new ArrayList<>();
        String sql = "SELECT " +
            "m.model_name, " +
            "ROUND(SUM(CASE WHEN e.status = 'completed' AND p.technique_name = 'zero-shot' THEN 1 ELSE 0 END) * 100.0 / " +
            "NULLIF(SUM(CASE WHEN p.technique_name = 'zero-shot' THEN 1 ELSE 0 END), 0), 1) AS zero_shot, " +
            "ROUND(SUM(CASE WHEN e.status = 'completed' AND p.technique_name = 'few-shot' THEN 1 ELSE 0 END) * 100.0 / " +
            "NULLIF(SUM(CASE WHEN p.technique_name = 'few-shot' THEN 1 ELSE 0 END), 0), 1) AS few_shot, " +
            "ROUND(SUM(CASE WHEN e.status = 'completed' AND p.technique_name = 'chain-of-thought' THEN 1 ELSE 0 END) * 100.0 / " +
            "NULLIF(SUM(CASE WHEN p.technique_name = 'chain-of-thought' THEN 1 ELSE 0 END), 0), 1) AS chain_of_thought, " +
            "ROUND(SUM(CASE WHEN e.status = 'completed' AND p.technique_name = 'structured-output' THEN 1 ELSE 0 END) * 100.0 / " +
            "NULLIF(SUM(CASE WHEN p.technique_name = 'structured-output' THEN 1 ELSE 0 END), 0), 1) AS structured_output, " +
            "ROUND(SUM(CASE WHEN e.status = 'completed' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 1) AS avg_success " +
            "FROM experiment e " +
            "JOIN llm_model m ON e.model_id = m.model_id " +
            "JOIN prompt_technique p ON e.technique_id = p.technique_id " +
            "GROUP BY m.model_name " +
            "ORDER BY avg_success DESC";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                ModelPerformanceDTO dto = new ModelPerformanceDTO();
                dto.setModelName(rs.getString("model_name"));
                dto.setZeroShot(rs.getDouble("zero_shot"));
                dto.setFewShot(rs.getDouble("few_shot"));
                dto.setChainOfThought(rs.getDouble("chain_of_thought"));
                dto.setStructuredOutput(rs.getDouble("structured_output"));
                dto.setAvgSuccess(rs.getDouble("avg_success"));
                performance.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return performance;
    }

    // ============================================================
    // RECENT EXPERIMENTS
    // ============================================================

    public List<ExperimentDTO> getRecentExperiments() {
        List<ExperimentDTO> experiments = new ArrayList<>();
        String sql = "SELECT e.experiment_id, e.transcript_id, m.model_name, " +
                     "p.technique_name, e.status, e.executed_at, e.rag_enabled " +
                     "FROM experiment e " +
                     "JOIN llm_model m ON e.model_id = m.model_id " +
                     "JOIN prompt_technique p ON e.technique_id = p.technique_id " +
                     "ORDER BY e.experiment_id DESC LIMIT 20";
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                ExperimentDTO dto = new ExperimentDTO();
                dto.setExperimentId(rs.getInt("experiment_id"));
                dto.setTranscriptId(rs.getInt("transcript_id"));
                dto.setModelName(rs.getString("model_name"));
                dto.setTechniqueName(rs.getString("technique_name"));
                dto.setStatus(rs.getString("status"));
                dto.setExecutedAt(rs.getTimestamp("executed_at"));
                dto.setRagEnabled(rs.getBoolean("rag_enabled"));
                experiments.add(dto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return experiments;
    }
}